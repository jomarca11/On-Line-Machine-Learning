.. code:: ipython3

    #Necesitamos reinstalar la version correcta de numpy por que la explicabilidad del modelo necesita al version 1.21
    !pip install --force-reinstall numpy==1.23.4 


.. parsed-literal::

    Collecting numpy==1.23.4
      Using cached numpy-1.23.4-cp39-cp39-win_amd64.whl (14.7 MB)
    Installing collected packages: numpy
      Attempting uninstall: numpy
        Found existing installation: numpy 1.23.4
        Uninstalling numpy-1.23.4:
          Successfully uninstalled numpy-1.23.4
    Successfully installed numpy-1.23.4
    

.. parsed-literal::

    ERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    daal4py 2021.6.0 requires daal==2021.4.0, which is not installed.
    numba 0.55.1 requires numpy<1.22,>=1.18, but you have numpy 1.23.4 which is incompatible.
    

.. code:: ipython3

    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    from river import drift

1.Análisis Exploratorio de los datos.
-------------------------------------

1.1 Carga de datos
~~~~~~~~~~~~~~~~~~

Procedemos a cargar el dataset.

.. code:: ipython3

    #1.Cargamos los datos
    #2. Comprobamos los datos nulos y vemos que no hay ninguno
    data_orig = pd.read_csv('C:/Users/jrmr/Master/TFM/PEC3/hungary_chickenpox/hungary_chickenpox.csv')
    data_orig['Date'] = pd.to_datetime(data_orig['Date'],format="%d/%m/%Y") # convertimos a fecha

1.2 Análisis descriptivo de los datos
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    #Comprobamos si hay nulos en los datos
    data_orig.isna().sum()




.. parsed-literal::

    Date        0
    BUDAPEST    0
    BARANYA     0
    BACS        0
    BEKES       0
    BORSOD      0
    CSONGRAD    0
    FEJER       0
    GYOR        0
    HAJDU       0
    HEVES       0
    JASZ        0
    KOMAROM     0
    NOGRAD      0
    PEST        0
    SOMOGY      0
    SZABOLCS    0
    TOLNA       0
    VAS         0
    VESZPREM    0
    ZALA        0
    dtype: int64



####1.2.1 Valores Nulos. Se Puede comprobar que **no existen ningún
valor vacio** en los datos.

.. code:: ipython3

    #añadimos el total de todas las ciudades
    data_orig['Total_Casos'] = data_orig.sum(axis=1)
    data_orig.head()


.. parsed-literal::

    C:\Users\jrmr\AppData\Local\Temp\ipykernel_16908\3302194850.py:2: FutureWarning: Dropping of nuisance columns in DataFrame reductions (with 'numeric_only=None') is deprecated; in a future version this will raise TypeError.  Select only valid columns before calling the reduction.
      data_orig['Total_Casos'] = data_orig.sum(axis=1)
    



.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Date</th>
          <th>BUDAPEST</th>
          <th>BARANYA</th>
          <th>BACS</th>
          <th>BEKES</th>
          <th>BORSOD</th>
          <th>CSONGRAD</th>
          <th>FEJER</th>
          <th>GYOR</th>
          <th>HAJDU</th>
          <th>...</th>
          <th>KOMAROM</th>
          <th>NOGRAD</th>
          <th>PEST</th>
          <th>SOMOGY</th>
          <th>SZABOLCS</th>
          <th>TOLNA</th>
          <th>VAS</th>
          <th>VESZPREM</th>
          <th>ZALA</th>
          <th>Total_Casos</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2005-01-03</td>
          <td>168</td>
          <td>79</td>
          <td>30</td>
          <td>173</td>
          <td>169</td>
          <td>42</td>
          <td>136</td>
          <td>120</td>
          <td>162</td>
          <td>...</td>
          <td>57</td>
          <td>2</td>
          <td>178</td>
          <td>66</td>
          <td>64</td>
          <td>11</td>
          <td>29</td>
          <td>87</td>
          <td>68</td>
          <td>1807</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2005-01-10</td>
          <td>157</td>
          <td>60</td>
          <td>30</td>
          <td>92</td>
          <td>200</td>
          <td>53</td>
          <td>51</td>
          <td>70</td>
          <td>84</td>
          <td>...</td>
          <td>50</td>
          <td>29</td>
          <td>141</td>
          <td>48</td>
          <td>29</td>
          <td>58</td>
          <td>53</td>
          <td>68</td>
          <td>26</td>
          <td>1407</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2005-01-17</td>
          <td>96</td>
          <td>44</td>
          <td>31</td>
          <td>86</td>
          <td>93</td>
          <td>30</td>
          <td>93</td>
          <td>84</td>
          <td>191</td>
          <td>...</td>
          <td>46</td>
          <td>4</td>
          <td>157</td>
          <td>33</td>
          <td>33</td>
          <td>24</td>
          <td>18</td>
          <td>62</td>
          <td>44</td>
          <td>1284</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2005-01-24</td>
          <td>163</td>
          <td>49</td>
          <td>43</td>
          <td>126</td>
          <td>46</td>
          <td>39</td>
          <td>52</td>
          <td>114</td>
          <td>107</td>
          <td>...</td>
          <td>54</td>
          <td>14</td>
          <td>107</td>
          <td>66</td>
          <td>50</td>
          <td>25</td>
          <td>21</td>
          <td>43</td>
          <td>31</td>
          <td>1255</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2005-01-31</td>
          <td>122</td>
          <td>78</td>
          <td>53</td>
          <td>87</td>
          <td>103</td>
          <td>34</td>
          <td>95</td>
          <td>131</td>
          <td>172</td>
          <td>...</td>
          <td>49</td>
          <td>11</td>
          <td>124</td>
          <td>63</td>
          <td>56</td>
          <td>7</td>
          <td>47</td>
          <td>85</td>
          <td>60</td>
          <td>1478</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 22 columns</p>
    </div>



1.2.2 Número de Instancias y variables.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Con la nueva columna que se ha añadido Total_Casos, que totaliza los
valores por cada instancia, tenemos 522 instancias y 22 variables.

.. code:: ipython3

    #Revisamos el número de instancias
    data_orig.shape




.. parsed-literal::

    (522, 22)



1.2.3 Outliers.
^^^^^^^^^^^^^^^

Revisando todas las provincias, se comprueba que, si que hay outliers
que deberían de detectarse cuando se esta procesando el streaming de
datos, y evitar entrenar con ellos.

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 1
    for row in axes:
        for ax in row:
            x = data_orig.iloc[:, i]
            sns.boxplot(x=x,ax=ax, orient='h')
            i += 1
    plt.tight_layout()
    plt.show()
    



.. image:: output_12_0.png


1.2.4 Análisis de Estacionalidad.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Hacemos un análisis de la **estacionalidad** de los datos.Se ha creado
un campo Total_Casos, para que añada un resumen de todos los datos. A
primera vista y para cada provincia, se detecta una estacionalidad en
los datos, así mismo en el total de los casos de varicela. Claramente se
ve unos picos en los contagios de varicela finales del primer trimestre
de cada año y un máximo en el segundo trimestre, decayendo rapidamente
en el tercer trimestre, posiblemente por la vacunación o por el clima
que empieza a ser mas fresco.Otra factor que pudiera afectar seria el
período escolar. En el cuarto trimestre empieza a subir otra vez hasta
el segundo trimestre y se vuelve al mismo ciclo de contagios.

.. code:: ipython3

    ax = data_orig.plot(x='Date',  figsize=(20,8))



.. image:: output_14_0.png


Primeramente vamos a descomponer la variable Total_Casos, en
estacionalidad, tendencia y la parte de residuos, para obtener una idea
general de la estructura de los datos.

.. code:: ipython3

    from statsmodels.tsa.seasonal import seasonal_decompose
    data_orig.set_index('Date', inplace=True)

.. code:: ipython3

    analysis = data_orig[['Total_Casos']].copy()
    decompose_result_mult = seasonal_decompose(analysis, model="additive")
    fig = decompose_result_mult.plot();
    fig.set_size_inches((12, 8))
    fig.tight_layout()
    plt.show()
    



.. image:: output_17_0.png


Pasamos a ver la estacionaldad, según cada provincia con más detalle.
Viendo las series de los gráficos individuales, se puede observar lo
siguiente:

-  El número de casos reportados depende de la cantidad de población.
   Aquellas provincias tienen mas población, reportan mas casos.
-  Las series exhiben una grans estacionalidad anual
-  Un gran número de provincias no reportaron ningún caso en verano.

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            x = data_orig.iloc[:, i]
            label=data_orig.columns[i]
            sns.lineplot(x = "Date", y = label, data=data_orig, ax=ax)
            i += 1
    plt.tight_layout()
    plt.show()



.. image:: output_19_0.png


1.2.5 Análisis de Estacionareidad.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Uno de los requisitos para comprobar la Autocorrelación y Correlacion
Parcial es que las series sean estacionarias. Se ha utilizado el test de
Dickey-Fuller para comprobar que todas las series son estacionarias. Si
no fueran estacionarias se deberían de modificar para que sí lo fueran.

.. code:: ipython3

    #estacionariedad
    from statsmodels.tsa.stattools import adfuller
    dict_estacionario={}
    Status = "Estacionaria"
    col=""
    for column in data_orig:
        result = adfuller(data_orig[column])
        if (result[1] <= 0.05) & (result[4]['5%'] > result[0]):
               # print("\u001b[32mStationary\u001b[0m")
               #Status= "Estacionaria"
               dict_estacionario[column]="Serie Estacionaria"
        else:
              #print("\x1b[31mNon-stationary\x1b[0m")
              #Status ="No Estacionaria"
              #col=column
              #break
              dict_estacionario[column]="Serie No Estacionaria"
    
    # Iterate over key/value pairs in dict and print them
    for key, value in dict_estacionario.items():
        print(key, ' : ', value)


.. parsed-literal::

    BUDAPEST  :  Serie Estacionaria
    BARANYA  :  Serie Estacionaria
    BACS  :  Serie Estacionaria
    BEKES  :  Serie Estacionaria
    BORSOD  :  Serie Estacionaria
    CSONGRAD  :  Serie Estacionaria
    FEJER  :  Serie Estacionaria
    GYOR  :  Serie Estacionaria
    HAJDU  :  Serie Estacionaria
    HEVES  :  Serie Estacionaria
    JASZ  :  Serie Estacionaria
    KOMAROM  :  Serie Estacionaria
    NOGRAD  :  Serie Estacionaria
    PEST  :  Serie Estacionaria
    SOMOGY  :  Serie Estacionaria
    SZABOLCS  :  Serie Estacionaria
    TOLNA  :  Serie Estacionaria
    VAS  :  Serie Estacionaria
    VESZPREM  :  Serie Estacionaria
    ZALA  :  Serie Estacionaria
    Total_Casos  :  Serie Estacionaria
    

1.2.6 AutoCorrelation and Partial Autocorrelation.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Vemos un modelo de Autocorrelacion que nos indica un modelo estacional
por la forma sinusiode de la gráfica para cada provincia. Viendo también
el gráfico de la Correlación Parcial donde hay pocos valores por encima
de la zona de confianza, se podrían modelar las series con un modelo
Auto Regresivo (AR), de orden 3.

.. code:: ipython3

    from statsmodels.graphics.tsaplots import plot_acf
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            x = data_orig.iloc[:, i]
            label=data_orig.columns[i]
            ax.set_xlabel(label)
            fig = plot_acf(x, lags=104, ax=ax)
            i += 1
    plt.tight_layout()
    plt.show()
    



.. image:: output_23_0.png


.. code:: ipython3

    from statsmodels.graphics.tsaplots import plot_pacf
    from statsmodels.graphics.tsaplots import plot_acf
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 16))
    i = 0
    for row in axes:
        for ax in row:
            x = data_orig.iloc[:, i]
            label=data_orig.columns[i]
            ax.set_xlabel(label)
            fig = plot_pacf(x, lags=104, ax=ax, method="ywmle",) 
            i += 1
    plt.tight_layout()
    plt.show()
    



.. image:: output_24_0.png


1.2.7 Resumen:
^^^^^^^^^^^^^^

Tenemos unas series Temporales que presentan las siguientes
características:

-  Presentan una **correlación temporal**: El número de casos de una
   semana esta corelacionado con el número de casos de semanas
   anteriores.
-  Presentan una estacionalidad anual muy fuerte.
-  Presentan un número de casos dependiente del tamaño y población de la
   provincia..
-  Las Series son estacionarias con lo que se pueden modelar usando
   modelos de Regresion (AR), viendo sus gráficos de AutoCorrelación y
   AutoCorrelación Parcial

2.Tareas Predictivas
====================

2.1 Corto Plazo (Nowcasting)
----------------------------

En este apartado vamos a realizar las tareas relacionadas con el
Nowcasting

.. code:: ipython3

    #Nowcasting con todos los regresores
    from river import compose
    from river import linear_model,tree
    from river import preprocessing
    from river import metrics, stats,optim
    from river import utils,dummy
    import pandas as pd
    
    import matplotlib.pyplot as plt
    import calendar
    label_num_casos ="Num. Casos"
    
    
    class StatisticRegressor(dummy.StatisticRegressor):
      # this method has to be overriden because of the first element, if it is None, then return something, 0 in this case
        def predict_one(self, x):
            yp = super().predict_one(x)
            if yp is None:
                return 0
            return yp
    
    df_datos=pd.DataFrame(columns=data_orig.columns)
    
    #Dataframes para recoger los errores y mostrarlos en las gráficas sin tener en cuenta los outliers
    df_error_mae_baseline=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_linear=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_hft=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_stg=pd.DataFrame(columns=data_orig.columns)
    
    #Dataframes para recoger los errores y mostrarlos en las gráficas considerando los outliers
    df_error_mae_baseline_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_linear_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_hft_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_stg_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    
    #Dataframes para recoger los errores considerando el Concept Drift
    df_error_mae_baseline_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_linear_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_hft_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_stg_concept=pd.DataFrame(columns=data_orig.columns)
    
    def get_ordinal_date(x):
        """Returns the ordinal date of a given x date
        """   
        return {'ordinal_date': x.toordinal()}
        
    def get_month(x):
        """Returns name of the month of a given x date
        """ 
        return {
            calendar.month_name[month]: month ==  pd.to_datetime(x).month
            for month in range(1, 13)
        }
    
    def get_month_distances(x):
        """Returns distances between months for a given date
        """ 
        return {
            calendar.month_name[month]: math.exp(-(x.month - month) ** 2)
            for month in range(1, 13)
        }
    
    #Baseline Model
    model_statistic_regressor = compose.Pipeline(
        ('ordinal_date', compose.FuncTransformer(get_ordinal_date)),
        ('scale', preprocessing.StandardScaler()),
        #('static_reg', dummy.StatisticRegressor(utils.Rolling( stats.Mean(), window_size=10)))
        ('statistic_reg', StatisticRegressor (stats.Shift(1))) #Consejo de Txus,empezar por algo sencillo y sin ventana ya que los demas no tienen ventana
    )
    # Linear Regression Model
    model_lin_reg = compose.Pipeline(
        ('ordinal_date', compose.FuncTransformer(get_ordinal_date)),
        ('scale', preprocessing.StandardScaler()),
        ('lin_reg', linear_model.LinearRegression(optimizer=optim.SGD(0.07))) #habria que tener en cuenta el lr_intercep
    )
    
    # Hoeffding Tree Regression Model
    model_hft_reg = compose.Pipeline(
        ('ordinal_date', compose.FuncTransformer(get_ordinal_date)),
        ('scale', preprocessing.StandardScaler()),
        #('HFT_reg', tree.HoeffdingTreeRegressor(grace_period=1,leaf_prediction ="adaptive",model_selector_decay=0.7,min_samples_split=5)) 
       ('HFT_reg', tree.HoeffdingTreeRegressor(grace_period=20,leaf_prediction ="model", leaf_model=linear_model.LinearRegression(optimizer=optim.SGD(0.08)))) 
    )
    
    #Stochastic Gradient Tree Regression Model
    model_stg_reg = compose.Pipeline(
        ('ordinal_date', compose.FuncTransformer(get_ordinal_date)),
        ('scale', preprocessing.StandardScaler()),
        ('SGT_reg', tree.SGTRegressor(gamma=0.5,grace_period=1,delta=0.1,lambda_value=0.2,feature_quantizer=tree.splitter.DynamicQuantizer(std_prop=0.8))) #SE ha tenido que parametrizar si no elresultado era malísimo
    )
    
    def evaluate_model(model,df_data,column,ax,etiqueta,check_drift=False, check_outliers=False, is_data_drifted=False): 
        """Calculate the metrics of the model and  model learning  without excluding outliers
           @model:model to evaluate
           @df_data: Time series data to be evalueated
           @check_drift: Boolean to check if we need to plot drifts or not
           @etiqueta: kind of model used [linear, stg, hft, statistic]
           @check_outliers: flag to see if checking outliers is needed or not
           @is_data_drifted: boolean, indicates wether the data is drifted or not. Helps to check the message in df_datos
        """
        metric = utils.Rolling(metrics.MAE(), 52)#52 semanas tiene el año que es un ciclo completo
        #lista para pintar los ejes rojos de los drifts
        drifts=[]
        dates = []
        y_trues = []
        y_preds = []
        if not is_data_drifted:
          std=df_data.std()
          mean=df_data.mean()
          outlier_value= mean+(3*std)
          #Contador de outliers
          num_outliers=df_data[df_data>outlier_value].count()
        
        if is_data_drifted :
          mensaje="3 MAE Datos con drift y sin usar adaptacion al drift"
        elif check_outliers:
          mensaje="2 MAE Datos sin drift y tratando outliers"
        else:
          mensaje ="1 MAE Datos sin drift y sin tratar outliers"
        #print (mensaje)
        #Inicializamos el detector de Drift, aqui solo queremos el drift para marcar las líneas verticales
        drift_detector = drift.ADWIN()
      
        i=0 #valor para añadir filas a los dataframes
        for x, y in df_data.T.iteritems():
          #Comprobamos si hay hay algun dríft. Lo añadimos a la lista para pintar la linea vertical
          if check_drift:
            drift_detector.update(y)
            if drift_detector.drift_detected:
               drifts.append(x)
          if  (check_outliers and y> outlier_value) :# Get rid  off outliers
            None
          else: #Trabajamos normalemente
            # Obtain the prior prediction and update the model in one go
            y_pred = model.predict_one(x)
     
            model.learn_one(x, y)
            # Update the error metric
            metric.update(y, y_pred)
    
            #get metric value for plotting
            if check_outliers==False:
              if etiqueta=="linear":
                df_error_mae_linear.at[i,column] =metric.get()
              elif etiqueta=='stg':
                df_error_mae_stg.at[i,column] =metric.get()
              elif etiqueta=='hft':
                df_error_mae_hft.at[i,column] =metric.get()
              elif etiqueta=='base_line':
                df_error_mae_baseline.at[i,column] =metric.get()
            else:
              if etiqueta=="linear":
                df_error_mae_linear_sin_outliers.at[i,column] =metric.get()
              elif etiqueta=='stg':
                df_error_mae_stg_sin_outliers.at[i,column] =metric.get()
              elif etiqueta=='hft':
                df_error_mae_hft_sin_outliers.at[i,column] =metric.get()
              elif etiqueta=='base_line':
                df_error_mae_baseline_sin_outliers.at[i,column] =metric.get()
    
            i=i+1
            
            # Store the true value and the prediction
            dates.append(x)
            y_trues.append(y)
            y_preds.append(y_pred)
              
        
        # Plotting the results
        value=round(metric.get(),2)
        
        if drifts is not None and check_drift:
          for drift_detected in drifts:
                  ax.axvline(drift_detected, color='red')
        ax.grid(alpha=0.75)
        ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Ground truth')
        ax.plot(dates, y_preds, lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
        ax.legend()
        ax.set_title(metric) 
        ax.set_xlabel(column)
        ax.set_ylabel(label_num_casos)
    
        #Añadimos filas con los datos para cada columna
        df_datos.at['Num Registros', column] = len(df_data)
        df_datos.at[mensaje+ ' '+etiqueta, column] = value
        
        #Añadimos filas con los datos de dispersion originales y num de outliers para cada provincia 
        if not is_data_drifted:
          df_datos.at['Num Outliers', column] = num_outliers
          df_datos.at['STD', column] = round(std,2)
          df_datos.at['MEAN', column] = round(mean,2)
        
      
    
    def evaluate_model_without_outliers(model,df_data,column,ax,etiqueta): 
    
        """Calculate the metrics of the model and  model learning excluding outliers, but considering drift
            @model:model to evaluate
            @df_data: Time series data to be evalueated
            @etiqueta: kind of model used [linear, stg, hft, statistic]
            @df_data: data always come with artificial drift
        """
         
        metric = utils.Rolling(metrics.MAE(), 52)#52 semanas tiene el año que es un ciclo completo
        dates = []
        y_trues = []
        y_preds = []
        #lista para pintar los ejes rojos de los drifts
        drifts = []
        std=df_data.std()
        mean=df_data.mean()
        outlier_value= mean+(3*std)
       
        
        #Inicializamos el detector de Drift
        drift_detector = drift.ADWIN()
    
        #contador de Drifts
        num_drifts = 0 
        i=0
       # print ("columna", column)
        #print ("num_drifts ",num_drifts)
        for x, y in df_data.T.iteritems():
         
          # Obtain the prior prediction and update the model in one go
           
          drift_detector.update(y)
          if not drift_detector.drift_detected:
            if  (y<=outlier_value) :# Get rid  off outliers
              y_pred = model.predict_one(x)
              model.learn_one(x, y)
              
              # Update the error metric
              metric.update(y, y_pred)
    
              #get metric value for plotting
              #print ("i ",i)
              if etiqueta=="linear":
                df_error_mae_linear_concept.at[i,column] =metric.get()
              elif etiqueta=='stg':
                df_error_mae_stg_concept.at[i,column] =metric.get()
              elif etiqueta=='hft':
                df_error_mae_hft_concept.at[i,column] =metric.get()
              elif etiqueta=='base_line':
                df_error_mae_baseline_concept.at[i,column] =metric.get()
    
                      
              # Store the true value and the prediction
              dates.append(x)
              y_trues.append(y)
              y_preds.append(y_pred)
              i=i+1
            #  print ("num_drifts if",num_drifts)
           # else:
            # num_outliers=num_outliers+1
            
          else:
            num_drifts=num_drifts+1
            model=model.clone() #reiniciamos el modelo y el detector de drift
            drift_detector = drift.ADWIN()
            drifts.append(x)
            
            # print ("num_drifts else",num_drifts)
            # print(f"Change detected at index {i}, input value: {y}")
             
             
          # Plot the results
      # fig, ax = plt.subplots(figsize=(9, 5))
        value=round(metric.get(),2)
        
    
        if drifts is not None:
          for drift_detected in drifts:
                  ax.axvline(drift_detected, color='red')
        ax.grid(alpha=0.75)
        ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Ground truth')
        ax.plot(dates, y_preds, lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
        ax.legend()
        ax.set_title(metric) 
        ax.set_xlabel(column)
        ax.set_ylabel(label_num_casos)
        #Añadimos filas con los datos para cada columna, esto es para hacer una tabla resumen. Ya veremos como
        # print ("num_drifts total",num_drifts)
           
        df_datos.at['Num Drifts', column] = num_drifts
        df_datos.at['4 MAE usando deteccion y adaptacion al drift_'+etiqueta, column] = value
        
    

2.1.1 Graficas y Nowcasting con los diferentes modelos.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

En este apartado se muestra la evolución del error, MAE, con respecto a
los valores reales y sus predicciones, para cada una de las ciudades y
modelo respectivo. De estas evoluciones de error, sacaremos datos en una
tabla para comparar los modelos.

2.1.1.1 Hoeffding Tree Regressor.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

En este apartado mostraremos el comportamiento del modelo.

2.1.1.1.1 Hoeffding Tree Regressor, sin tratar los outliers
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Hoeffding Tree Regressor Model
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_32_0.png


2.1.1.1.2 Hoeffding Tree Regressor, tratando los outliers
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Hoeffding Tree Regressor Model
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=False,check_outliers=True,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_34_0.png


2.1.1.2 Linear Regressor Model, sin tener en cuenta los outliers.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1.2.1 Linear Regressor Model, sin tratar los outliers
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Linear Regressor Model
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_lin_reg.clone(),df_data,label,ax,etiqueta="linear",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_37_0.png


2.1.1.2.2 Linear Regressor Model, tratando los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Linear Regressor Model
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_lin_reg.clone(),df_data,label,ax,etiqueta="linear",check_drift=False,check_outliers=True,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_39_0.png


2.1.1.3 SGT Regressor (Stochastic Gradient Tree for Regression) Model.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1.3.1 SGT Regressor (Stochastic Gradient Tree for Regression) Model, sin tener en cuenta los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_stg_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_stg_reg.clone(),df_data,label,ax,etiqueta="stg",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_42_0.png


2.1.1.3.2 SGT Regressor (Stochastic Gradient Tree for Regression) Model, tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_stg_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_stg_reg.clone(),df_data,label,ax,etiqueta="stg",check_drift=False,check_outliers=True,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_44_0.png


2.1.1.4 Statistic Regressor Mode (Dummy). Devuelve el valor en el instante anterior.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1.4.1 Statistic Regressor Mode (Dummy). Devuelve el valor en el instante anterior, sin tener en cuenta los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_statistc_regressor)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_statistic_regressor.clone(),df_data,label,ax,etiqueta="base_line",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_47_0.png


2.1.1.4.2 Statistic Regressor Mode (Dummy). Devuelve el valor en el instante anterior, tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_statistc_regressor)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_model(model_statistic_regressor.clone(),df_data,label,ax,etiqueta="base_line",check_drift=False,check_outliers=True,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo Dummy, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_49_0.png


2.1.1.5 Gráficas, comparación de la métrica de error seleccionada (MAE).Para cada ciudad se muestra la evolución de cada uno de los modelos.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Se compara la evolución del error, MAE, de cada uno de los 4 modelos
para cada ciudad.Se puede comprobar que de los 4 el mejor modelo es el
Linear Regression y el Hoeffing Tree Regressor ya que éste tiene en las
hojas un modelo de regresión Lineal (Linear Regressor).Estas dos
métricas en las gráficas casi estan solapadas por que soy muy parecidas.

2.1.1.5.1 Graficas, comparación de la métrica de error seleccionada (MAE)con baseline, sin tratar los outliers, para cada ciudad.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline[label].plot(ax=ax)
            df_error_mae_stg[label].plot(ax=ax)
            df_error_mae_linear[label].plot(ax=ax)
            df_error_mae_hft[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["Baseline", "SGTRegressor","LinearRegressor","HFTreeRegressor"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE)con baseline, sin tratat los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_52_0.png


2.1.1.5.2 Graficas, comparación de la métrica de error seleccionada (MAE)con baseline tratando los outliers, para cada ciudad.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline_sin_outliers[label].plot(ax=ax)
            df_error_mae_stg_sin_outliers[label].plot(ax=ax)
            df_error_mae_linear_sin_outliers[label].plot(ax=ax)
            df_error_mae_hft_sin_outliers[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["Baseline", "SGTRegressor","LinearRegressor","HFTreeRegressor"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE)con baseline, tratando los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_54_0.png


2.1.1.6 Graficas de cada regresor **para cada ciudad** comparando la evolución del error tratando los outliers vs sin tratarlos.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.1.1.6.1 Hoeffding Tree Regressor, comparando la evolución del error Tratando los outliers vs Sin tratarlos.
                                                                                                             

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_hft[label].plot(ax=ax)
            df_error_mae_hft_sin_outliers[label].plot(ax=ax)
            ax.legend(["Sin tratar outliers", "Tratando Outliers"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle(" Hoeffding Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_57_0.png


2.1.1.6.2 LinearTree Regressor, comparando la evolución del error Tratando los outliers vs Sin tratarlos.
                                                                                                         

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_linear[label].plot(ax=ax)
            df_error_mae_linear_sin_outliers[label].plot(ax=ax)
            ax.legend(["Sin tratar outliers", "Tratando Outliers"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Linear Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_59_0.png


2.1.1.6.3 Stochastic Gradient Tree Regressor, comparando la evolución del error Tratando los outliers vs Sin tratarlos.
                                                                                                                       

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_stg[label].plot(ax=ax)
            df_error_mae_stg_sin_outliers[label].plot(ax=ax)
            ax.legend(["Sin tratar outliers", "Tratando Outliers"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Stochastic Gradient Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_61_0.png


2.1.1.6.4 Statistict Regressor (DUMMY), comparando la evolución del error Tratando los outliers vs Sin tratarlos.
                                                                                                                 

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline[label].plot(ax=ax)
            df_error_mae_baseline_sin_outliers[label].plot(ax=ax)
            ax.legend(["Sin tratar outliers", "Tratando Outliers"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Stochastic Gradient Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_63_0.png


2.1.2 Creando Concept Drift
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Se ha incorporado un Concept Drift de forma artificial para ver el
comportamiento del algoritmo con los datos de la varicela.

.. code:: ipython3

    #Creamos el Concept Drift , para analizar los datos
    df_data_orig_drifted=data_orig.copy()
    for column in df_data_orig_drifted.columns:
       for index, value in df_data_orig_drifted[column].items(): 
        if (index >=pd.Timestamp('2008-01-01') and index <=pd.Timestamp('2011-12-30') ):
            df_data_orig_drifted[column].at[index]= value *0.3
        
    

Con las siguientes gráficas, se comprueba que efectivamente se ven los
Concept Drifts incorporados mediante unas líneas verticales de color
rojo.

.. code:: ipython3

    #Comprobamos que el detector de drift detecta los cambios que hemos introducido mediante gráficas
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            drift_detector = drift.ADWIN()
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            df_data.plot(ax=ax)
            for j, val in df_data.items():
                drift_detector.update(val)   # Data is processed one sample at a time
                if drift_detector.drift_detected:
                  # The drift detector indicates after each sample if there is a drift in the data
                   #print(f'Change detected at index {j}')
                    ax.axvline(j, color='red')
            ax.set_xlabel(label)  
            ax.set_ylabel(label_num_casos)
            i += 1
    plt.tight_layout()
    plt.show()
    



.. image:: output_67_0.png


2.1.3 Graficas y Nowcasting con los diferentes modelos, tratando el Concept Drift o no.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

En este apartado se muestra la evolución del error, MAE, con respecto a
los valores reales y sus predicciones teniendo en cuenta los outliers y
la deteccion del Concep Drift inducido en los datos.

2.1.3.1 Hoeffding Tree Regressor Model.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

En este apartado mostraremos el comportamiento del modelo a partir del
drift que hemos inducido artificialmente, con un detector de drift como
es el ADWIN y como se comportará el modelo sin un detector de drift.
Claramente se puede observar en las gráficas que el error, MAE, es menor
cuando se adapta el modelo al drift.

2.1.3.1.1 Hoeffding Tree Regressor, con drift en los datos y usando detección y adaptación al drift
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_hft_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model_without_outliers (model_hft_reg.clone(),df_data,label,ax,"hft")
            i += 1
    fig.suptitle("Hoeffding Tree Regressor model, adaptánsose al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_71_0.png


2.1.3.1.2 Hoeffding Tree Regressor, con drift en los datos y sin usar detección y adaptación al drift
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_hft_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=True,is_data_drifted=True)
            i += 1
    fig.suptitle("Hoeffding Tree Regressor model, sin adaptación al Concept Drift", fontsize=20)
    
    plt.tight_layout()
    plt.show()



.. image:: output_73_0.png


2.1.3.2 Linear Regressor Model
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

En este caso se comprueba lo mismo con el el Hoeffding Tree Regressor.
Al adaptarse al drift, el error es menor que sin adaptación al drift.

2.1.3.2.1 Linear Regressor, con drift en los datos y usando detección y adaptación al drift
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Modelo linear Regressor
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model_without_outliers(model_lin_reg.clone(),df_data,label,ax,"linear")
            i += 1
    fig.suptitle("Linear Regressor model, adaptánsose al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_76_0.png


2.1.3.1.2 Linear Regressor, con drift en los datos y sin usar detección y adaptación al drift
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Modelo linear Regressor
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model(model_lin_reg.clone(),df_data,label,ax,etiqueta="linear",check_drift=True,is_data_drifted=True)
            i += 1
    fig.suptitle("Linear Regressor model, sin adaptación al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_78_0.png


2.1.3.3 SGT Regressor (Stochastic Gradient Tree for Regression) Model.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Aunque este modelo es el que peor se comporta en general, también se
puede comprobar como la adaptación al drift provoca una disminución en
el error,MAE, obtenido.

2.1.3.3.1 Stochastic Gradient Tree Regressor, con drift en los datos y usando detección y adaptación al drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_stg_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model_without_outliers(model_stg_reg.clone(),df_data,label,ax,"stg")
            i += 1
    fig.suptitle("tochastic Gradient Tree Regressor, adaptánsose al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_81_0.png


2.1.3.3.2 Stochastic Gradient Tree Regressor, con drift en los datos y sin usar detección y adaptación al drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #evaluate_model(model_stg_reg)
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model(model_stg_reg.clone(),df_data,label,ax,etiqueta="stg",check_drift=True,is_data_drifted=True)
            i += 1
    fig.suptitle("tochastic Gradient Tree Regressor sin adaptación al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_83_0.png


2.1.3.3 Statistic Regressor Model (Dummy). Devuelve el valor en el instante anterior.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Este modelo, simplemente es el “modelo a batir” y aunque su predicción
sea simplemente devolver el valor en el instante anterior, se puede
comprobar que la adaptación al drift, hace que el error, MAE, sea menor.

2.1.3.3.1 Statistic Regressor, con drift en los datos y usando detección y adaptación al drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Model Statistic Regressor
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model_without_outliers(model_statistic_regressor.clone(),df_data,label,ax,"base_line")
            i += 1
    fig.suptitle("Statistic Regressor Model (Dummy),adaptánsose al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_86_0.png


2.1.3.3.2 Statistic Regressor, con drift en los datos y sin usar detección y adaptación al drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    #Model Statistic Regressor
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:,i]
            label=df_data_orig_drifted.columns[i]
            evaluate_model(model_statistic_regressor.clone(),df_data,label,ax,etiqueta="base_line",check_drift=True,is_data_drifted=True)
            i += 1
    fig.suptitle("Statistic Regressor Model (Dummy), sin adaptación al Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_88_0.png


2.1.4 Graficas, comparación de la métrica de error seleccionada (MAE)según los diferentes modelos para cada ciudatd, teniendo en cuenta los outliers y detectando y adaptandose al Concept Drift.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

En este apartado se comprueba como los modelos que incorporan un
detector de Drift, ante una situación de Concept Drift en los datos,
estos se adaptan mejor. Se adaptan antes y con mas suavidad que los
modelos sin incorporar detector de drift

2.1.3.4.1 Gráficas de la evolución del error por regresor, con drift en los datos y usando detección y adaptación al drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline_concept[label].plot(ax=ax)
            df_error_mae_stg_concept[label].plot(ax=ax)
            df_error_mae_linear_concept[label].plot(ax=ax)
            df_error_mae_hft_concept[label].plot(ax=ax)
            ax.legend(["Baseline", "SGTRegressor","LinearRegressor","HFTreeRegressor"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Gráficas de evolución del error con drift en los datos y adaptación al drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_91_0.png


2.1.3.4.2 Gráficas de la evolución del error por regresor, con drift en los datos y sin usar detección y adaptación al drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline[label].plot(ax=ax)
            df_error_mae_stg[label].plot(ax=ax)
            df_error_mae_linear[label].plot(ax=ax)
            df_error_mae_hft[label].plot(ax=ax)
            ax.legend(["Baseline", "SGTRegressor","LinearRegressor","HFTreeRegressor"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Gráficas de evolución del error con drift en los datos pero sin adaptación al drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_93_0.png


2.1.5 Graficas de cada regresor **para cada ciudad** comparando la evolución del error contemplando el drift y adaptándose al drift o sin adaptarse.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

2.1.5.1 Hoeffding Tree Regressor, comparando la evolución del error con drift en los datos usando detección y adaptación al drift, y sin usar detección de drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_hft[label].plot(ax=ax)
            df_error_mae_hft_concept[label].plot(ax=ax)
            ax.legend(["Sin contemplar Drift", "Tratando Drift"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle(" Hoeffding Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_96_0.png


2.1.5.2 Linear Regressor, comparando la evolución del error con drift en los datos usando detección y adaptación al drift, y sin usar detección de drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_linear[label].plot(ax=ax)
            df_error_mae_linear_concept[label].plot(ax=ax)
            ax.legend(["Sin contemplar Drift", "Tratando Drift"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Linear Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_98_0.png


2.1.5.3 Stochastic Gradient Tree Regressor, comparando la evolución del error con drift en los datos usando detección y adaptación al drift, y sin usar detección de drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_stg[label].plot(ax=ax)
            df_error_mae_stg_concept[label].plot(ax=ax)
            ax.legend(["Sin contemplar Drift", "Tratando Drift"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle("Stochastic Gradient Tree Regressor comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_100_0.png


2.1.5. Statistic Regressor (Dummy), comparando la evolución del error con drift en los datos usando detección y adaptación al drift, y sin usar detección de drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_baseline[label].plot(ax=ax)
            df_error_mae_baseline_concept[label].plot(ax=ax)
            ax.legend(["Sin contemplar Drift", "Tratando Drift"]);
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            i += 1
    fig.suptitle(" Statistic Regressor (Dummy), comparación de evolución del error", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_102_0.png


2.1.6 Tabla de resultados Now Casting
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    #Tabla con recopilación de los datos
    df_datos.drop(columns=['Total_Casos']).sort_index(ascending=True)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BUDAPEST</th>
          <th>BARANYA</th>
          <th>BACS</th>
          <th>BEKES</th>
          <th>BORSOD</th>
          <th>CSONGRAD</th>
          <th>FEJER</th>
          <th>GYOR</th>
          <th>HAJDU</th>
          <th>HEVES</th>
          <th>JASZ</th>
          <th>KOMAROM</th>
          <th>NOGRAD</th>
          <th>PEST</th>
          <th>SOMOGY</th>
          <th>SZABOLCS</th>
          <th>TOLNA</th>
          <th>VAS</th>
          <th>VESZPREM</th>
          <th>ZALA</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers base_line</th>
          <td>48.1</td>
          <td>13.25</td>
          <td>38.54</td>
          <td>13.02</td>
          <td>37.21</td>
          <td>22.63</td>
          <td>17.58</td>
          <td>17.65</td>
          <td>28.94</td>
          <td>20.62</td>
          <td>23.94</td>
          <td>9.81</td>
          <td>10.6</td>
          <td>37.19</td>
          <td>12.94</td>
          <td>13.79</td>
          <td>13.23</td>
          <td>15.27</td>
          <td>20.33</td>
          <td>18.81</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers hft</th>
          <td>43.35</td>
          <td>9.79</td>
          <td>29.93</td>
          <td>11.93</td>
          <td>28.64</td>
          <td>19.94</td>
          <td>14.73</td>
          <td>14.42</td>
          <td>22.13</td>
          <td>14.67</td>
          <td>19.0</td>
          <td>8.1</td>
          <td>8.29</td>
          <td>30.44</td>
          <td>12.19</td>
          <td>12.99</td>
          <td>10.5</td>
          <td>11.23</td>
          <td>14.64</td>
          <td>14.8</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers linear</th>
          <td>42.75</td>
          <td>9.79</td>
          <td>29.59</td>
          <td>12.0</td>
          <td>28.6</td>
          <td>19.73</td>
          <td>14.64</td>
          <td>14.46</td>
          <td>22.25</td>
          <td>14.65</td>
          <td>19.14</td>
          <td>8.04</td>
          <td>8.44</td>
          <td>30.2</td>
          <td>11.98</td>
          <td>12.92</td>
          <td>10.24</td>
          <td>11.18</td>
          <td>14.39</td>
          <td>14.55</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers stg</th>
          <td>50.96</td>
          <td>14.39</td>
          <td>30.51</td>
          <td>16.69</td>
          <td>37.2</td>
          <td>23.59</td>
          <td>20.65</td>
          <td>17.5</td>
          <td>30.1</td>
          <td>21.96</td>
          <td>27.11</td>
          <td>10.77</td>
          <td>11.77</td>
          <td>39.3</td>
          <td>12.57</td>
          <td>15.34</td>
          <td>10.48</td>
          <td>13.34</td>
          <td>22.86</td>
          <td>18.15</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers base_line</th>
          <td>38.46</td>
          <td>13.25</td>
          <td>22.33</td>
          <td>13.02</td>
          <td>37.21</td>
          <td>22.38</td>
          <td>17.58</td>
          <td>17.65</td>
          <td>28.94</td>
          <td>20.62</td>
          <td>23.94</td>
          <td>9.81</td>
          <td>10.6</td>
          <td>37.19</td>
          <td>12.94</td>
          <td>13.79</td>
          <td>13.23</td>
          <td>15.27</td>
          <td>20.33</td>
          <td>10.96</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers hft</th>
          <td>37.32</td>
          <td>9.78</td>
          <td>17.93</td>
          <td>11.93</td>
          <td>28.64</td>
          <td>17.29</td>
          <td>14.72</td>
          <td>14.42</td>
          <td>22.13</td>
          <td>14.66</td>
          <td>19.0</td>
          <td>8.1</td>
          <td>8.31</td>
          <td>30.44</td>
          <td>12.17</td>
          <td>12.98</td>
          <td>10.52</td>
          <td>11.22</td>
          <td>14.61</td>
          <td>8.45</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers linear</th>
          <td>37.27</td>
          <td>9.8</td>
          <td>17.93</td>
          <td>12.0</td>
          <td>28.6</td>
          <td>17.16</td>
          <td>14.63</td>
          <td>14.46</td>
          <td>22.25</td>
          <td>14.65</td>
          <td>19.14</td>
          <td>8.04</td>
          <td>8.46</td>
          <td>30.2</td>
          <td>11.97</td>
          <td>12.92</td>
          <td>10.26</td>
          <td>11.18</td>
          <td>14.39</td>
          <td>8.44</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers stg</th>
          <td>52.99</td>
          <td>17.74</td>
          <td>29.63</td>
          <td>11.42</td>
          <td>44.95</td>
          <td>20.46</td>
          <td>24.93</td>
          <td>18.86</td>
          <td>26.89</td>
          <td>20.93</td>
          <td>26.45</td>
          <td>11.02</td>
          <td>13.6</td>
          <td>50.93</td>
          <td>12.7</td>
          <td>18.37</td>
          <td>10.59</td>
          <td>12.16</td>
          <td>23.04</td>
          <td>10.46</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift y sin usar adaptacion al drift base_line</th>
          <td>48.1</td>
          <td>13.25</td>
          <td>38.54</td>
          <td>13.02</td>
          <td>37.21</td>
          <td>22.63</td>
          <td>17.58</td>
          <td>17.65</td>
          <td>28.94</td>
          <td>20.62</td>
          <td>23.94</td>
          <td>9.81</td>
          <td>10.6</td>
          <td>37.19</td>
          <td>12.94</td>
          <td>13.79</td>
          <td>13.23</td>
          <td>15.27</td>
          <td>20.33</td>
          <td>18.81</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift y sin usar adaptacion al drift hft</th>
          <td>43.35</td>
          <td>9.79</td>
          <td>29.93</td>
          <td>11.93</td>
          <td>28.64</td>
          <td>19.94</td>
          <td>14.73</td>
          <td>14.42</td>
          <td>22.13</td>
          <td>14.67</td>
          <td>19.0</td>
          <td>8.1</td>
          <td>8.29</td>
          <td>30.44</td>
          <td>12.19</td>
          <td>12.99</td>
          <td>10.5</td>
          <td>11.23</td>
          <td>14.64</td>
          <td>14.8</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift y sin usar adaptacion al drift linear</th>
          <td>42.75</td>
          <td>9.79</td>
          <td>29.59</td>
          <td>12.0</td>
          <td>28.6</td>
          <td>19.73</td>
          <td>14.64</td>
          <td>14.46</td>
          <td>22.25</td>
          <td>14.65</td>
          <td>19.14</td>
          <td>8.04</td>
          <td>8.44</td>
          <td>30.2</td>
          <td>11.98</td>
          <td>12.92</td>
          <td>10.24</td>
          <td>11.18</td>
          <td>14.39</td>
          <td>14.55</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift y sin usar adaptacion al drift stg</th>
          <td>52.23</td>
          <td>14.39</td>
          <td>30.51</td>
          <td>15.15</td>
          <td>35.73</td>
          <td>23.74</td>
          <td>20.65</td>
          <td>21.09</td>
          <td>32.76</td>
          <td>24.92</td>
          <td>27.11</td>
          <td>10.44</td>
          <td>11.71</td>
          <td>35.94</td>
          <td>12.54</td>
          <td>15.29</td>
          <td>10.51</td>
          <td>13.34</td>
          <td>22.39</td>
          <td>14.33</td>
        </tr>
        <tr>
          <th>4 MAE usando deteccion y adaptacion al drift_base_line</th>
          <td>38.46</td>
          <td>13.25</td>
          <td>22.85</td>
          <td>13.02</td>
          <td>30.92</td>
          <td>21.0</td>
          <td>17.58</td>
          <td>17.65</td>
          <td>22.44</td>
          <td>20.62</td>
          <td>21.71</td>
          <td>9.63</td>
          <td>8.04</td>
          <td>34.12</td>
          <td>13.42</td>
          <td>13.79</td>
          <td>13.23</td>
          <td>13.62</td>
          <td>20.33</td>
          <td>10.96</td>
        </tr>
        <tr>
          <th>4 MAE usando deteccion y adaptacion al drift_hft</th>
          <td>37.12</td>
          <td>11.15</td>
          <td>18.43</td>
          <td>11.93</td>
          <td>24.7</td>
          <td>16.56</td>
          <td>14.92</td>
          <td>14.43</td>
          <td>17.94</td>
          <td>14.66</td>
          <td>15.75</td>
          <td>8.17</td>
          <td>6.23</td>
          <td>26.06</td>
          <td>12.72</td>
          <td>12.98</td>
          <td>10.41</td>
          <td>9.96</td>
          <td>16.04</td>
          <td>8.46</td>
        </tr>
        <tr>
          <th>4 MAE usando deteccion y adaptacion al drift_linear</th>
          <td>37.06</td>
          <td>9.82</td>
          <td>18.48</td>
          <td>12.0</td>
          <td>24.77</td>
          <td>16.44</td>
          <td>14.62</td>
          <td>14.47</td>
          <td>16.13</td>
          <td>14.65</td>
          <td>16.05</td>
          <td>8.14</td>
          <td>6.39</td>
          <td>26.09</td>
          <td>12.46</td>
          <td>12.92</td>
          <td>10.15</td>
          <td>9.96</td>
          <td>14.37</td>
          <td>8.44</td>
        </tr>
        <tr>
          <th>4 MAE usando deteccion y adaptacion al drift_stg</th>
          <td>46.08</td>
          <td>14.8</td>
          <td>23.67</td>
          <td>15.95</td>
          <td>29.78</td>
          <td>23.5</td>
          <td>19.38</td>
          <td>20.9</td>
          <td>21.99</td>
          <td>19.84</td>
          <td>22.24</td>
          <td>10.06</td>
          <td>12.03</td>
          <td>32.46</td>
          <td>11.64</td>
          <td>15.84</td>
          <td>11.57</td>
          <td>12.29</td>
          <td>21.55</td>
          <td>10.83</td>
        </tr>
        <tr>
          <th>MEAN</th>
          <td>101.25</td>
          <td>34.2</td>
          <td>37.17</td>
          <td>28.91</td>
          <td>57.08</td>
          <td>31.49</td>
          <td>33.27</td>
          <td>41.44</td>
          <td>47.1</td>
          <td>29.69</td>
          <td>40.87</td>
          <td>25.64</td>
          <td>21.85</td>
          <td>86.1</td>
          <td>27.61</td>
          <td>29.85</td>
          <td>20.35</td>
          <td>22.47</td>
          <td>40.64</td>
          <td>19.87</td>
        </tr>
        <tr>
          <th>Num Drifts</th>
          <td>3</td>
          <td>4</td>
          <td>3</td>
          <td>3</td>
          <td>4</td>
          <td>3</td>
          <td>4</td>
          <td>5</td>
          <td>4</td>
          <td>3</td>
          <td>4</td>
          <td>4</td>
          <td>4</td>
          <td>3</td>
          <td>3</td>
          <td>2</td>
          <td>2</td>
          <td>4</td>
          <td>4</td>
          <td>2</td>
        </tr>
        <tr>
          <th>Num Outliers</th>
          <td>7</td>
          <td>8</td>
          <td>8</td>
          <td>11</td>
          <td>6</td>
          <td>11</td>
          <td>4</td>
          <td>5</td>
          <td>6</td>
          <td>10</td>
          <td>4</td>
          <td>4</td>
          <td>9</td>
          <td>4</td>
          <td>7</td>
          <td>7</td>
          <td>9</td>
          <td>11</td>
          <td>7</td>
          <td>6</td>
        </tr>
        <tr>
          <th>Num Registros</th>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
          <td>522</td>
        </tr>
        <tr>
          <th>STD</th>
          <td>76.35</td>
          <td>32.57</td>
          <td>36.84</td>
          <td>37.62</td>
          <td>50.73</td>
          <td>33.79</td>
          <td>31.4</td>
          <td>36.01</td>
          <td>44.61</td>
          <td>31.86</td>
          <td>37.28</td>
          <td>24.47</td>
          <td>22.03</td>
          <td>66.77</td>
          <td>26.72</td>
          <td>31.81</td>
          <td>23.27</td>
          <td>25.01</td>
          <td>40.7</td>
          <td>22.0</td>
        </tr>
      </tbody>
    </table>
    </div>



2.1.7 Conclusiones:
~~~~~~~~~~~~~~~~~~~

-  Para cada ciudad: >Viendo la tabla con los distintos errores, tomados
   de todas las mediciones anteriores, se puede ver que el modelo que
   mejor predice, menos MAE presenta, es el modelo de regresión lineal,
   al que hemos llamado **Linear Regressor Model**, aunque el **Hoefding
   Tree Regressor Model**, tiene unas prestaciones muy parecidas ya que
   en sus hojas tiene un modelo de regresion lineal igual al del
   **Linear Regressor Model**. Las métricas se han sacado comparando los
   modelos contra el modelo base **Statistic Regressor**, que
   simplemente lo que devuelve es el valor en el instante anterior. >Las
   mediciones se han hecho primeramente sin tratar los outliers, luego
   se han tratado los outliers, simplemente no aprendiendo de ellos
   cuando se detectaban, dando una métricas mejores.Luego además de
   tratar los outliers se introdujo un drift artificial en los datos
   para ver como se comportaban los algoritmos y la respuesta fué, que
   se comportan mejor si los modelos se adaptan al drift que si no lo
   hacen. Se adaptan antes y con mayor suavidad al drift. Para detectar
   los posibles Concept Drift se ha usado un detector de drift
   ADWIN.Cada vez que se detecta un drift, el modelo es reiniciado para
   que aprenda de los datos mas recientes y no tenga en cuenta los mas
   antiguos.

-  Comparando ciudades: > Comparando las mediciones entre ciudades, las
   ciudades que menor MAE presentan independientemente del modelo usado,
   aunque por supuesto hay diferencias entre modelos y siguen siendo los
   menores MAE aquellos que tratan los outliers y el drift, son aquellos
   que presentan una menor dispersión, menor desviación tipica y menor
   media, en los datos. Estas ciudades son aquellas que presentan una
   menor población o han contraido un menor número de casos de varicela.
   A mayor dispersión en los datos, mayor es el error.

2.2 Predicciones a Largo Plazo
------------------------------

En este apartado vamos a realizar las tareas relacionadas con las
Previsiones a largo Plazo. Aquí vamos a establecer tres horizontes
temporales. Un horizonte temporal de 1 mes, 2 meses y otro horizonte
temporal de 3 meses.

2.2.1 Aquí definiremos las librerias y métodos necesarios.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

La librería utilizada como en el resto de trabajo, es la riverML, pero
en este caso vamos a sobreescribir el método iter_evaluate para adaptar
al tratamiento del concept drift cuando este, esté presente.

.. code:: ipython3

    #cargamos los datos de nuevo para independizarlo del resto del notebook
    data_orig = pd.read_csv('C:/Users/jrmr/Master/TFM/PEC3/hungary_chickenpox/hungary_chickenpox.csv')
    data_orig['Date'] = pd.to_datetime(data_orig['Date'],format="%d/%m/%Y") # convertimos a fecha
    data_orig.set_index('Date', inplace=True)
    label_num_casos ="Num. Casos"

.. code:: ipython3

    #Si se definen alguna librería varias veces es para no tener que ejecutar todo el código cada vez se hace una prueba
    from river import time_series, evaluate
    from river import compose
    from river import linear_model,tree,preprocessing,optim
    import calendar,math, datetime as dt
    from river import metrics,base
    import typing, statistics
    from river.time_series.evaluate import _iter_with_horizon
    
    df_datos_largo_plazo=pd.DataFrame(columns=data_orig.columns)
    #Dataframes para recoger los errores y mostrarlos en las gráficas sin tener en cuenta los outliers
    df_error_mae_un_mes=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores y mostrarlos en las gráficas considerando los outliers
    df_error_mae_un_mes_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_sin_outliers=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores base line y mostrarlos en las gráficas sin tener en cuenta los outliers
    df_error_mae_un_mes_baseline=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_baseline=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_baseline=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores base line y mostrarlos en las gráficas considerando los outliers
    df_error_mae_un_mes_sin_outliers_baseline=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_sin_outliers_baseline=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_sin_outliers_baseline=pd.DataFrame(columns=data_orig.columns)
    
    def get_ordinal_date(x):
       
        return {'ordinal_date': x.toordinal()}
    
    #definimos el modelo ya ajustado con sus hiperparámetros
    model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
    
    model_s = (
          get_ordinal_date|
         time_series.SNARIMAX(
             p=4,
             d=0,
             q=9,
             m=52,
             sp=4,
             sq=9,
             regressor=(
                 preprocessing.StandardScaler() | 
                 linear_model.LinearRegression(
                     intercept_init=110,
                     optimizer=optim.SGD(0.001),
                     intercept_lr=0.3
                 )
             )
         )
     )
    
    #redefinimos el metodo iter_evaluate
    def iter_evaluate(
        dataset: base.typing.Dataset,
        model: time_series.base.Forecaster,
        metric: metrics.base.RegressionMetric,
        horizon: int,
        agg_func: typing.Callable[[list[float]], float] = None,
        grace_period: int = None,
        outlier_value=0
    ):
        """Evaluates the performance of a forecaster on a time series dataset and yields results.
        This does exactly the same as `evaluate.progressive_val_score`. The only difference is that
        this function returns an iterator, yielding results at every step. This can be useful if you
        want to have control over what you do with the results. For instance, you might want to plot
        the results.
        Parameters
        ----------
        dataset
            A sequential time series.
        model
            A forecaster.
        metric
            A regression metric.
        horizon
        agg_func
        grace_period
            Initial period during which the metric is not updated. This is to fairly evaluate models
            which need a warming up period to start producing meaningful forecasts. The value of this
            parameter is equal to the horizon by default.
        outlier value
            if >0 it means handling the outliers
    
        """
       
        horizon_metric = (
            time_series.HorizonAggMetric(metric, agg_func)
            if agg_func
            else time_series.HorizonMetric(metric)
        )
        steps = _iter_with_horizon(dataset, horizon)
        num_outliers=0
        #y_horizon =la ground truth en el horizonte
        grace_period = horizon if grace_period is None else grace_period
        
        for _ in range(grace_period):
          
            x, y, x_horizon, y_horizon = next(steps)
            if (y>outlier_value and outlier_value>0):
              None
            else:
              model.learn_one(y=y, x=x)  # type: ignore
    
        
        if (outlier_value>0):#si queremos checker los outliers
          for x, y, x_horizon, y_horizon in steps:
            
              if (y>outlier_value):
                  #num_outliers+=1
                  None
              else:
                y_pred = model.forecast(horizon, xs=x_horizon)
                horizon_metric.update(y_horizon, y_pred)
                model.learn_one(y=y, x=x)  # type: ignore
                yield x, y, y_pred, horizon_metric,num_outliers
        else:
             for x, y, x_horizon, y_horizon in steps:
                y_pred = model.forecast(horizon, xs=x_horizon)
                horizon_metric.update(y_horizon, y_pred)
                model.learn_one(y=y, x=x)  # type: ignore
                yield x, y, y_pred, horizon_metric#,num_outliers #aqui el num de outliers sera 0 siempre, pero por igualar datos devueltos
              
    
    #redefinimos el metodo iter_evaluate para tratar el drift
    def iter_evaluate_with_drift(
        dataset: base.typing.Dataset,
        model: time_series.base.Forecaster,
        metric: metrics.base.RegressionMetric,
        horizon: int,
        agg_func: typing.Callable[[list[float]], float] = None,
        grace_period: int = None,
        outlier_value=0,
        check_drift=False,
        model_to_check="snarimax"
    ):
        """Evaluates the performance of a forecaster on a time series dataset and yields results.
        This does exactly the same as `evaluate.progressive_val_score`. The only difference is that
        this function returns an iterator, yielding results at every step. This can be useful if you
        want to have control over what you do with the results. For instance, you might want to plot
        the results.
        Parameters
        ----------
        dataset
            A sequential time series.
        model
            A forecaster.
        metric
            A regression metric.
        horizon
        agg_func
        grace_period
            Initial period during which the metric is not updated. This is to fairly evaluate models
            which need a warming up period to start producing meaningful forecasts. The value of this
            parameter is equal to the horizon by default.
        """
           
        horizon_metric = (
            time_series.HorizonAggMetric(metric, agg_func)
            if agg_func
            else time_series.HorizonMetric(metric)
        )
        steps = _iter_with_horizon(dataset, horizon)
        
        #y_horizon =la ground truth en el horizonte
        grace_period = horizon if grace_period is None else grace_period
    
        adwin=drift.ADWIN(10)
        lista_drifts=[]
       
        for _ in range(grace_period):
          
            x, y, x_horizon, y_horizon = next(steps)
            if (y>outlier_value and outlier_value>0):
              None
            else:
              model.learn_one(y=y, x=x)  # type: ignore
    
        if check_drift==True:
          for x, y, x_horizon, y_horizon in steps:
            adwin.update(y)
            if adwin.drift_detected:
              adwin=drift.ADWIN(10)
              lista_drifts.append(x)
              if model_to_check=="snarimax":
                
                model= (
                        get_ordinal_date|
                      time_series.SNARIMAX(
                          p=4,
                          d=0,
                          q=9,
                          m=52,
                          sp=4,
                          sq=9,
                          regressor=(
                              preprocessing.StandardScaler() | 
                              linear_model.LinearRegression(
                                  intercept_init=110,
                                  optimizer=optim.SGD(0.001),
                                  intercept_lr=0.3
                              )
                          )
                      )
                  )
              else:
                model.clone()
            if (y<=outlier_value):
                model.learn_one(y=y, x=x)  # type: ignore
                y_pred = model.forecast(horizon, xs=x_horizon)
                horizon_metric.update(y_horizon, y_pred)
                yield x, y, y_pred, horizon_metric,lista_drifts
                
        else:
          
            for x, y, x_horizon, y_horizon in steps:
              if (y<=outlier_value):
                y_pred = model.forecast(horizon, xs=x_horizon)
                horizon_metric.update(y_horizon, y_pred)
                model.learn_one(y=y, x=x)  # type: ignore
                yield x, y, y_pred, horizon_metric,lista_drifts
    
    #-------------------------------------------------------------------------------------#
    #Método que entrena el modelo y crea las métricas
    def evaluate_forecasting(modelo,data,ax,column,horizonte,outlier_value=0, model ='snarimax'):
        """Evaluates the performance of a forecaster on a time series dataset and yields results.
        This does exactly the same as `evaluate.progressive_val_score`. The only difference is that
        this function returns an iterator, yielding results at every step. This can be useful if you
        want to have control over what you do with the results. For instance, you might want to plot
        the results.
        Parameters
        ----------
        dataset
            A sequential time series.
        model
            A forecaster.
       
        horizon horizon to forecast
        outlier value
            if >0 it means handling the outliers
    
        """
        metricas = iter_evaluate(
            dataset=data.T.iteritems(),
            model=modelo,
            metric=metrics.MAE(),
            horizon=horizonte,
            agg_func=statistics.mean,
            outlier_value=outlier_value
            )
        dates = []
        y_trues = []
        y_preds = []
        lista=[]
        
        horizon=horizonte
        mensaje=""
        mensaje_outliers=""
        num_outliers=0
        i=0
        if outlier_value==0:
          mensaje ="1 MAE Datos sin drift y sin tratar outliers con horizonte= "
          
        else:
          mensaje ="2 MAE Datos sin drift y tratando outliers con horizonte= "
           
        for m in metricas:
              dates.append(m[0])
              y_trues.append(m[1])
              y_preds.append(m[2][horizon-1])
              lista.append(m[3].get())
              #num_outliers=m[4]
              
              if model=='snarimax':
                if outlier_value >0:
                  if horizonte==4:
                    df_error_mae_un_mes.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses.at[i,column] =round(m[3].get(),2)
                else:
                  if horizonte==4:
                    df_error_mae_un_mes_sin_outliers.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_sin_outliers.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_sin_outliers.at[i,column] =round(m[3].get(),2)
              else:
                if outlier_value >0:
                  if horizonte==4:
                    df_error_mae_un_mes_baseline.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_baseline.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_baseline.at[i,column] =round(m[3].get(),2)
                else:
                  if horizonte==4:
                    df_error_mae_un_mes_sin_outliers_baseline.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_sin_outliers_baseline.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_sin_outliers_baseline.at[i,column] =round(m[3].get(),2)
    
              i+=1
        metric=round(sum(lista)/len(lista),2) #average of MAES for one horizon forecast
        # Plot the results
        ax=ax
        ax.grid(alpha=0.75)
        ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Ground truth')
        ax.plot(dates, y_preds, lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
        ax.legend()
        ax.set_title("MAE "+str(metric))
        ax.set_xlabel(column)
        ax.set_ylabel(label_num_casos)
        
        df_datos_largo_plazo.at[mensaje+ ' '+str(horizonte)+' modelo ='+model, column] = metric
     
        if outlier_value==0:
          std=round(data.std(),2)
          mean=round(data.mean(),2)
          df_datos_largo_plazo.at['STD', column] = std
          df_datos_largo_plazo.at['MEAN', column] = mean
          outlier_value= mean+(3*std)
          #Contador de outliers
          num_outliers=df_data[df_data>outlier_value].count()
          df_datos_largo_plazo.at['Num Outliers', column] = num_outliers
    

2.2.2 Gráficas de los diferentes modelos comparando las predicciones en el horizonte h, con los valores verdaderos h-t.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

2.2.2.1 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 1 mes ( 4 semanas ).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.1.1 Gráfica y Comportamiento de la prediccion a 1 mes (4 semanas). Sin tratar los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=4,outlier_value=0)
      
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_114_0.png


2.2.2.1.2 Gráfica y Comportamiento de la prediccion a 1 mes (4 semanas). Tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=4,outlier_value=outlier_value)
            #evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_116_0.png


2.2.2.2 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 2 meses (8 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.2.1 Gráfica y Comportamiento de la predicción a 2 meses (8 semanas). Sin tratar los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=8,outlier_value=0)
      
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_119_0.png


2.2.2.2.2 Gráfica y Comportamiento de la predicción a 2 meses (8 semanas). Tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=8,outlier_value=outlier_value)
           
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_121_0.png


2.2.2.3 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 3 meses (12 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.3.1 Gráfica y Comportamiento de la predicción a 3 meses (12 semanas). Sin tratar los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=12,outlier_value=0)
      
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_124_0.png


2.2.2.3.2 Gráfica y Comportamiento de la predicción a 3 meses (12 semanas). Tratando los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_s,df_data,ax,label,horizonte=12,outlier_value=outlier_value)
           
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_126_0.png




2.2.2.4 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 1 mes.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.4.1 Gráfica y Comportamiento de la prediccion a 1 mes (4 semánas). Sin tratar los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=4,outlier_value=0,model='baseline')
      
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_130_0.png


2.2.2.1.2 Gráfica y Comportamiento de la prediccion a 1 mes (4 semánas). Tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    _baselinefig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=4,outlier_value=outlier_value,model='baseline')
            #evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_132_0.png


2.2.2.5 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 2 meses (8 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.5.1 Gráfica y Comportamiento de la prediccion a 2 meses (8 semanas). Sin tratar los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=8,outlier_value=0,model='baseline')
      
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_135_0.png


2.2.2.5.2 Gráfica y Comportamiento de la prediccion a 2 meses (8 semanas). Tratando los outliers.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=8,outlier_value=outlier_value,model='baseline')
            #evaluate_model(model_hft_reg.clone(),df_data,label,ax,etiqueta="hft",check_drift=False,check_outliers=False,is_data_drifted=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_137_0.png


2.2.2.6 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 3 meses (12 semanas ).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.2.6.1 Gráfica y Comportamiento de la prediccion a 3 meses (12 semanas). Sin tratar los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=12,outlier_value=0,model='baseline')
      
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_140_0.png


2.2.2.6.2 Gráfica y Comportamiento de la prediccion a 3 meses (12 semanas). Tratando los outliers.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    
    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting(model_dummy,df_data,ax,label,horizonte=12,outlier_value=outlier_value,model='baseline')
      
            i += 1
    fig.suptitle("Comportamiento del modelo, HoltWinter (Base Line) a un mes sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_142_0.png


2.2.3 Gráficas, comparación de la métrica de error seleccionada (MAE)de los distintos horizontes con el Modelo SNARIMAX y Baseline.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Se compara la evolución del error, MAE, de cada uno de los modelos para
cada ciudad.En este apartado se puede comprobar que la comparación de
los distintos horizontes del modelo SNARIMAX vs distintos horizontes
Baseline, en el modelo SNARIMAX se consigue un menor error MAE, tanto en
la versión del tratamiento de los outliers como sin tratarlos. También
se adivina que a menor horizonte, mayor precisión en las predicciones.

2.2.3.1 Gráficas de error y comportamiento del modelo SNARIMAX con varios horizontes, para cada ciudad sin tratar los outliers.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes[label].plot(ax=ax)
            df_error_mae_dos_meses[label].plot(ax=ax)
            df_error_mae_tres_meses[label].plot(ax=ax)
            df_error_mae_un_mes_baseline[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNARIMAX Un Mes", "SNARIMAX Dos Meses","SNARIMAX tres Meses","Baseline Un Mes", "Baseline Dos Meses","Baseline tres Meses"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX vs Baseline sin tratar los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_145_0.png


2.2.3.2 Gráficas de error y comportamiento del modelo HoltWinters (Baseline) con varios horizontes , para cada ciudad tratando los outliers.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes_sin_outliers[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_outliers[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_outliers[label].plot(ax=ax)
            df_error_mae_un_mes_sin_outliers_baseline[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_outliers_baseline[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_outliers_baseline[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNARIMAX Un Mes", "SNARIMAX Dos Meses","SNARIMAX tres Meses","Baseline Un Mes", "Baseline Dos Meses","Baseline tres Meses"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX vs Baseline tratando los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_147_0.png


2.2.4 Graficas de cada modelo **para cada ciudad** comparando la evolución del error tratando los outliers vs sin tratarlos.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Se puede ver que as predicciones a mas corto plazo presentan menos error
y que a su vez, el tratamiento de los outliers, nos conduce a unas
predicciones mas precisas, menos error.

2.2.4.1 Modelo SNARIMAX con los distintos horizontes (1,2 y 3 meses) tratando outliers y sin tratar.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes[label].plot(ax=ax)
            df_error_mae_dos_meses[label].plot(ax=ax)
            df_error_mae_tres_meses[label].plot(ax=ax)
            df_error_mae_un_mes_sin_outliers[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_outliers[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_outliers[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNMAX Un Mes", "SNMAX Dos Meses","SNMAX tres Meses","SNMAX Un M sin out", "SNMAX Dos M sin out","SNMAX tres M sin out"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX, tratando outliers  vs sin tratar los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_150_0.png


2.2.4.2 Modelo Baseline con los distintos horizontes (1,2 y 3 meses) tratando outliers y sin tratar.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes_baseline[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline[label].plot(ax=ax)
            df_error_mae_un_mes_sin_outliers_baseline[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_outliers_baseline[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_outliers_baseline[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["Bline Un Mes", "Bline Dos Meses","Bline tres Meses","Bline Un M sin out", "Bline Dos M sin out","Bline tres M sin out"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo Baseline, tratando outliers  vs sin tratar los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_152_0.png


2.2.5 Aqui vamos a introducir un Concept Drift artificial para ver como se comportan las predicciones a largo plazo
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_data_orig_drifted=data_orig.copy()
    for column in df_data_orig_drifted.columns:
       for index, value in df_data_orig_drifted[column].items(): 
        if (index >=pd.Timestamp('2008-01-01') and index <=pd.Timestamp('2011-12-30') ):
            df_data_orig_drifted[column].at[index]= value *0.3

.. code:: ipython3

    #Método que entrena el modelo y crea las métricas
    
    #Dataframes para recoger los errores y mostrarlos en las gráficas sin tener en cuenta los outliers
    df_error_mae_un_mes_sin_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_sin_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_sin_concept=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores y mostrarlos en las gráficas tratando concept drift
    df_error_mae_un_mes_con_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_con_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_con_concept=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores base line y mostrarlos en las gráficas sin tener en cuenta los outliers
    df_error_mae_un_mes_baseline_sin_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_baseline_sin_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_baseline_sin_concept=pd.DataFrame(columns=data_orig.columns)
    
    
    #Dataframes para recoger los errores base line y mostrarlos en las gráficas considerando los outliers
    df_error_mae_un_mes_baseline_con_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_dos_meses_baseline_con_concept=pd.DataFrame(columns=data_orig.columns)
    df_error_mae_tres_meses_baseline_con_concept=pd.DataFrame(columns=data_orig.columns)
    def evaluate_forecasting_with_drift(modelo,data,ax,column,horizonte,outlier_value=0, model ='snarimax',check_drift=False):
      
        metricas = iter_evaluate_with_drift(
            dataset=data.T.iteritems(),
            model=modelo,
            metric=metrics.MAE(),
            horizon=horizonte,
            agg_func=statistics.mean,
            outlier_value=outlier_value,
            check_drift=check_drift,
            model_to_check=model
            )
        dates = []
        y_trues = []
        y_preds = []
        lista=[]
        lista_drifts=[]
        horizon=horizonte
        std=round(data.std(),2)
        mean=round(data.mean(),2)
        i=0
        if check_drift:
          mensaje ="3 MAE Datos con drift en datos y tratando el drift con horizonte= "
          mensaje_drifts ="5 Num Drifts Datos con drift en datos y tratando el drift con horizonte= "
        else:
          mensaje ="4 MAE Datos con drift en datos y sin tratar el drift con horizonte= "
          
        for m in metricas:
              
              dates.append(m[0])
              y_trues.append(m[1])
              y_preds.append(m[2][horizon-1])
              lista.append(m[3].get())
              lista_drifts=m[4]
              if model=='snarimax':
                if check_drift:
                  if horizonte==4:
                    df_error_mae_un_mes_con_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_con_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_con_concept.at[i,column] =round(m[3].get(),2)
                else:
                  if horizonte==4:
                    df_error_mae_un_mes_sin_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_sin_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_sin_concept.at[i,column] =round(m[3].get(),2)
              else: #model= baseline
                if  check_drift:
                  if horizonte==4:
                    df_error_mae_un_mes_baseline_con_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_baseline_con_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_baseline_con_concept.at[i,column] =round(m[3].get(),2)
                else:
                  if horizonte==4:
                    df_error_mae_un_mes_baseline_sin_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==8:
                    df_error_mae_dos_meses_baseline_sin_concept.at[i,column] =round(m[3].get(),2)
                  elif horizonte==12:
                    df_error_mae_tres_meses_baseline_sin_concept.at[i,column] =round(m[3].get(),2)
    
              i+=1
        
        metric=round(sum(lista)/len(lista),2)#average of MAES
        # Plot the results
        ax=ax
       
        for drift in lista_drifts:
                  ax.axvline(drift, color='red')
        ax.grid(alpha=0.75)
        ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Ground truth')
        ax.plot(dates, y_preds, lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
        ax.legend()
        ax.set_title("MAE "+str(metric))
        ax.set_xlabel(column)
        ax.set_ylabel(label_num_casos)
        df_datos_largo_plazo.at['STD', column] = std
        df_datos_largo_plazo.at['MEAN', column] = mean
        df_datos_largo_plazo.at[mensaje+ ' '+str(horizonte)+' modelo ='+model+' semanas', column] = metric
        if check_drift:
          df_datos_largo_plazo.at[mensaje_drifts+ ' '+str(horizonte)+' modelo ='+model+' semanas', column] = len(lista_drifts)
    
      
    

2.2.5.1 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 1 meses (4 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.1.1 Gráfica y comportamiento de la predicción a 1 mes (4 semenas). Sin tratar el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=4,outlier_value=outlier_value,model="snarimax",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_158_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 1 mes (4 semenas).Tratando el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=4,outlier_value=outlier_value,model="snarimax",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_160_0.png


2.2.5.2 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 2 meses (8 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.2.1 Gráfica y comportamiento de la predicción a 2 meses (8 semenas). Sin tratar el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=8,outlier_value=outlier_value,model="snarimax",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_163_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 2 meses (8 semenas).Tratando el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=8,outlier_value=outlier_value,model="snarimax",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_165_0.png


2.2.5.3 Gráficas y comportamiento del modelo SNARIMAX con horizonte a 3 meses (12 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.3.1 Gráfica y comportamiento de la predicción a 3 meses (12 semenas). Sin tratar el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=12,outlier_value=outlier_value,model="snarimax",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_168_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 3 meses (12 semenas).Tratando el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_s,df_data,ax,label,horizonte=12,outlier_value=outlier_value,model="snarimax",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_170_0.png




2.2.5.1 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 1 mes (4 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.1.1 Gráfica y comportamiento de la predicción a 1 mes (4 semenas). Sin tratar el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=4,outlier_value=outlier_value,model="baseline",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_174_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 1 mes (4 semenas).Tratando el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=4,outlier_value=outlier_value,model="baseline",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_176_0.png


2.2.5.2 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 2 meses (8 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.2.1 Gráfica y comportamiento de la predicción a 2 meses (8 semenas). Sin tratar el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=8,outlier_value=outlier_value,model="baseline",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_179_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 2 meses (8 semenas).Tratando el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=8,outlier_value=outlier_value,model="baseline",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_181_0.png


2.2.5.3 Gráficas y comportamiento del modelo HoltWinter (Base Line) con horizonte a 3 meses (12 semanas).
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.5.3.1 Gráfica y comportamiento de la predicción a 3 meses (12 semenas). Sin tratar el Concept Drift.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=12,outlier_value=outlier_value,model="baseline",check_drift=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_184_0.png


2.2.5.1.2 Gráfica y comportamiento de la predicción a 3 meses (12 semenas).Tratando el Concept Drift.
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            media=df_data.mean()
            std=df_data.std()
            outlier_value=media+(3*std)
            model_dummy=time_series.HoltWinters(alpha=0.6,beta=0.04,gamma=0.9)
            label=data_orig.columns[i]
            
            model_s = ( get_ordinal_date|  time_series.SNARIMAX(
                    p=4,
                    d=0,
                    q=9,
                    m=52,
                    sp=4,
                    sq=9,
                    regressor=(
                        preprocessing.StandardScaler() | 
                        linear_model.LinearRegression(
                            intercept_init=110,
                            optimizer=optim.SGD(0.001),
                            intercept_lr=0.3
                        )
                    )
                )
            )
            evaluate_forecasting_with_drift(model_dummy,df_data,ax,label,horizonte=12,outlier_value=outlier_value,model="baseine",check_drift=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando el Concept Drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_186_0.png




2.2.6 Gráficas, comparación de la métrica de error seleccionada (MAE)de los distintos horizontes con el Modelo SNARIMAX y Baseline.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Se compara la evolución del error, MAE, de cada uno de los modelos para
cada ciudad.En este apartado se puede comprobar que la comparación de
los distintos horizontes del modelo SNARIMAX vs distintos horizontes
Baseline, en el modelo SNARIMAX se consigue un menor error MAE, tanto en
la versión del tratamiento del Concept Drift como sin tratarlo. También
se adivina que a menor horizonte, mayor precisión en las predicciones.

2.2.6.1 Gráficas de error y comportamiento del modelo SNARIMAX con varios horizontes, para cada ciudad sin tratar el Concept Drift.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes_sin_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_concept[label].plot(ax=ax)
            df_error_mae_un_mes_baseline_sin_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline_sin_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline_sin_concept[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNARIMAX Un Mes", "SNARIMAX Dos Meses","SNARIMAX tres Meses","Baseline Un Mes", "Baseline Dos Meses","Baseline tres Meses"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX vs HoltWinters(Baseline) sin tratar el Concept Drift, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_190_0.png


2.2.6.2 Gráficas de error y comportamiento del modelo HoltWinters (Baseline) con varios horizontes , para cada ciudad tratando el Concept Drift.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes_con_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_con_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_con_concept[label].plot(ax=ax)
            df_error_mae_un_mes_baseline_con_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline_con_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline_con_concept[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNARIMAX Un Mes", "SNARIMAX Dos Meses","SNARIMAX tres Meses","Baseline Un Mes", "Baseline Dos Meses","Baseline tres Meses"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX vs HoltWinters(Baseline) tratando el Concept Drift, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_192_0.png


2.2.7 Graficas de cada modelo **para cada ciudad** comparando la evolución del error tratando el Concept Drift vs sin Tratarlo.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Se puede ver que as predicciones a mas corto plazo presentan menos error
y que a su vez, el tratamiento del Concept drif, nos conduce a unas
predicciones mas precisas, menos error para cada uno de los diferentes
modelos aunque el modelo SNARIMAX, saca mejores prestaciones que el
HoltWinters (Base Line)

2.2.4.1 Modelo SNARIMAX con los distintos horizontes (1,2 y 3 meses) tratando el Concept Drift vs Sin tratar.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes[label].plot(ax=ax)
            df_error_mae_dos_meses[label].plot(ax=ax)
            df_error_mae_tres_meses[label].plot(ax=ax)
            df_error_mae_un_mes_sin_outliers[label].plot(ax=ax)
            df_error_mae_dos_meses_sin_outliers[label].plot(ax=ax)
            df_error_mae_tres_meses_sin_outliers[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["SNMAX Un Mes", "SNMAX Dos Meses","SNMAX tres Meses","SNMAX Un M sin out", "SNMAX Dos M sin out","SNMAX tres M sin out"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo SNARIMAX, tratando outliers  vs sin tratar los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_195_0.png


2.2.4.2 Modelo Baseline con los distintos horizontes (1,2 y 3 meses) tratando el Concept Drift vs Sin tratar.
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(28, 17))
    i = 0
    for row in axes:
        for ax in row:
            label=data_orig.columns[i]
            ax.set_title(label)
            df_error_mae_un_mes_baseline_con_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline_con_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline_con_concept[label].plot(ax=ax)
            df_error_mae_un_mes_baseline_sin_concept[label].plot(ax=ax)
            df_error_mae_dos_meses_baseline_sin_concept[label].plot(ax=ax)
            df_error_mae_tres_meses_baseline_sin_concept[label].plot(ax=ax)
            ax.set_xlabel(label_num_casos)
            ax.set_ylabel("MAE")
            ax.legend(["Bline Un Mes trat concept", "Bline Dos Meses trat concept","Bline tres Meses trat concept","Bline Un M sin", "Bline Dos M sin","Bline tres M sin"]);
            i += 1
    fig.suptitle("Comparación de la métrica de error seleccionada (MAE) Modelo Baseline, tratando outliers  vs sin tratar los outliers, para cada ciudad", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_197_0.png


2.2.8 Tabla de Resultados
~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df_datos_largo_plazo.sort_index(ascending=True)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BUDAPEST</th>
          <th>BARANYA</th>
          <th>BACS</th>
          <th>BEKES</th>
          <th>BORSOD</th>
          <th>CSONGRAD</th>
          <th>FEJER</th>
          <th>GYOR</th>
          <th>HAJDU</th>
          <th>HEVES</th>
          <th>JASZ</th>
          <th>KOMAROM</th>
          <th>NOGRAD</th>
          <th>PEST</th>
          <th>SOMOGY</th>
          <th>SZABOLCS</th>
          <th>TOLNA</th>
          <th>VAS</th>
          <th>VESZPREM</th>
          <th>ZALA</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  12 modelo =baseline</th>
          <td>74.22</td>
          <td>36.48</td>
          <td>35.51</td>
          <td>80.33</td>
          <td>57.38</td>
          <td>34.93</td>
          <td>87.64</td>
          <td>59.85</td>
          <td>85.85</td>
          <td>30.6</td>
          <td>60.59</td>
          <td>27.31</td>
          <td>36.34</td>
          <td>76.4</td>
          <td>34.01</td>
          <td>47.17</td>
          <td>50.84</td>
          <td>34.8</td>
          <td>44.49</td>
          <td>46.47</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  12 modelo =snarimax</th>
          <td>62.91</td>
          <td>25.99</td>
          <td>31.11</td>
          <td>28.72</td>
          <td>40.05</td>
          <td>26.35</td>
          <td>24.08</td>
          <td>30.03</td>
          <td>36.38</td>
          <td>25.86</td>
          <td>32.98</td>
          <td>23.21</td>
          <td>18.48</td>
          <td>53.8</td>
          <td>23.43</td>
          <td>27.02</td>
          <td>17.77</td>
          <td>19.71</td>
          <td>35.52</td>
          <td>17.08</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  4 modelo =baseline</th>
          <td>45.55</td>
          <td>23.68</td>
          <td>23.12</td>
          <td>53.16</td>
          <td>38.94</td>
          <td>22.3</td>
          <td>54.59</td>
          <td>37.12</td>
          <td>54.4</td>
          <td>20.16</td>
          <td>40.54</td>
          <td>19.0</td>
          <td>23.73</td>
          <td>48.62</td>
          <td>21.24</td>
          <td>32.87</td>
          <td>32.57</td>
          <td>21.9</td>
          <td>27.96</td>
          <td>29.18</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  4 modelo =snarimax</th>
          <td>41.88</td>
          <td>18.1</td>
          <td>22.03</td>
          <td>24.06</td>
          <td>32.09</td>
          <td>19.39</td>
          <td>17.61</td>
          <td>20.56</td>
          <td>27.33</td>
          <td>18.25</td>
          <td>22.88</td>
          <td>17.4</td>
          <td>13.87</td>
          <td>35.91</td>
          <td>16.67</td>
          <td>22.5</td>
          <td>13.33</td>
          <td>15.37</td>
          <td>24.6</td>
          <td>13.05</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  8 modelo =baseline</th>
          <td>60.24</td>
          <td>30.0</td>
          <td>29.18</td>
          <td>66.31</td>
          <td>49.83</td>
          <td>29.49</td>
          <td>72.91</td>
          <td>49.43</td>
          <td>72.74</td>
          <td>25.7</td>
          <td>52.97</td>
          <td>23.39</td>
          <td>30.39</td>
          <td>63.23</td>
          <td>26.9</td>
          <td>40.59</td>
          <td>43.22</td>
          <td>29.16</td>
          <td>34.54</td>
          <td>38.75</td>
        </tr>
        <tr>
          <th>1 MAE Datos sin drift y sin tratar outliers con horizonte=  8 modelo =snarimax</th>
          <td>51.75</td>
          <td>21.8</td>
          <td>26.77</td>
          <td>26.36</td>
          <td>35.64</td>
          <td>22.45</td>
          <td>20.73</td>
          <td>24.74</td>
          <td>32.11</td>
          <td>22.4</td>
          <td>28.28</td>
          <td>20.32</td>
          <td>16.38</td>
          <td>44.22</td>
          <td>20.12</td>
          <td>24.94</td>
          <td>15.59</td>
          <td>17.35</td>
          <td>29.88</td>
          <td>15.25</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  12 modelo =baseline</th>
          <td>70.98</td>
          <td>35.31</td>
          <td>33.92</td>
          <td>29.0</td>
          <td>55.48</td>
          <td>33.06</td>
          <td>56.11</td>
          <td>64.87</td>
          <td>93.39</td>
          <td>28.87</td>
          <td>63.6</td>
          <td>26.03</td>
          <td>35.64</td>
          <td>75.17</td>
          <td>32.94</td>
          <td>47.86</td>
          <td>50.0</td>
          <td>32.52</td>
          <td>41.86</td>
          <td>46.74</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  12 modelo =snarimax</th>
          <td>61.61</td>
          <td>25.32</td>
          <td>30.17</td>
          <td>25.6</td>
          <td>38.42</td>
          <td>25.27</td>
          <td>23.85</td>
          <td>29.85</td>
          <td>34.99</td>
          <td>24.74</td>
          <td>31.19</td>
          <td>21.78</td>
          <td>17.98</td>
          <td>53.71</td>
          <td>22.11</td>
          <td>25.22</td>
          <td>17.2</td>
          <td>18.23</td>
          <td>33.63</td>
          <td>16.79</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  4 modelo =baseline</th>
          <td>44.03</td>
          <td>23.13</td>
          <td>22.17</td>
          <td>19.78</td>
          <td>36.9</td>
          <td>21.29</td>
          <td>34.14</td>
          <td>38.29</td>
          <td>57.74</td>
          <td>19.26</td>
          <td>41.79</td>
          <td>18.44</td>
          <td>23.36</td>
          <td>47.7</td>
          <td>20.7</td>
          <td>32.79</td>
          <td>32.06</td>
          <td>20.5</td>
          <td>26.91</td>
          <td>29.19</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  4 modelo =snarimax</th>
          <td>40.9</td>
          <td>17.6</td>
          <td>21.34</td>
          <td>18.5</td>
          <td>30.73</td>
          <td>18.69</td>
          <td>17.5</td>
          <td>20.14</td>
          <td>26.76</td>
          <td>17.58</td>
          <td>22.14</td>
          <td>16.67</td>
          <td>13.52</td>
          <td>35.42</td>
          <td>15.52</td>
          <td>21.05</td>
          <td>12.91</td>
          <td>14.2</td>
          <td>23.68</td>
          <td>12.84</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  8 modelo =baseline</th>
          <td>57.86</td>
          <td>29.12</td>
          <td>27.88</td>
          <td>24.02</td>
          <td>47.54</td>
          <td>28.15</td>
          <td>47.85</td>
          <td>53.53</td>
          <td>77.18</td>
          <td>24.53</td>
          <td>55.09</td>
          <td>22.5</td>
          <td>29.92</td>
          <td>62.18</td>
          <td>26.23</td>
          <td>40.9</td>
          <td>42.59</td>
          <td>27.41</td>
          <td>32.69</td>
          <td>38.9</td>
        </tr>
        <tr>
          <th>2 MAE Datos sin drift y tratando outliers con horizonte=  8 modelo =snarimax</th>
          <td>50.74</td>
          <td>21.2</td>
          <td>25.93</td>
          <td>21.72</td>
          <td>34.28</td>
          <td>21.6</td>
          <td>20.55</td>
          <td>24.42</td>
          <td>30.97</td>
          <td>21.55</td>
          <td>27.02</td>
          <td>19.3</td>
          <td>15.98</td>
          <td>44.07</td>
          <td>18.58</td>
          <td>23.4</td>
          <td>15.11</td>
          <td>16.15</td>
          <td>28.47</td>
          <td>15.02</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  12 modelo =baseine semanas</th>
          <td>53.85</td>
          <td>27.32</td>
          <td>23.67</td>
          <td>21.81</td>
          <td>86.67</td>
          <td>24.02</td>
          <td>52.08</td>
          <td>59.02</td>
          <td>40.02</td>
          <td>21.82</td>
          <td>30.06</td>
          <td>20.11</td>
          <td>30.87</td>
          <td>58.78</td>
          <td>27.4</td>
          <td>39.77</td>
          <td>43.36</td>
          <td>27.8</td>
          <td>34.01</td>
          <td>42.21</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  12 modelo =snarimax semanas</th>
          <td>46.27</td>
          <td>18.1</td>
          <td>21.13</td>
          <td>18.88</td>
          <td>29.19</td>
          <td>17.98</td>
          <td>18.04</td>
          <td>22.19</td>
          <td>25.21</td>
          <td>18.6</td>
          <td>22.66</td>
          <td>15.72</td>
          <td>14.08</td>
          <td>39.82</td>
          <td>16.6</td>
          <td>18.91</td>
          <td>12.64</td>
          <td>13.81</td>
          <td>25.29</td>
          <td>13.42</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  4 modelo =baseline semanas</th>
          <td>32.12</td>
          <td>17.62</td>
          <td>15.34</td>
          <td>14.59</td>
          <td>52.49</td>
          <td>15.39</td>
          <td>28.45</td>
          <td>33.06</td>
          <td>23.37</td>
          <td>13.85</td>
          <td>20.65</td>
          <td>13.97</td>
          <td>19.78</td>
          <td>36.59</td>
          <td>16.76</td>
          <td>26.96</td>
          <td>27.7</td>
          <td>16.35</td>
          <td>20.32</td>
          <td>25.61</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  4 modelo =snarimax semanas</th>
          <td>29.51</td>
          <td>12.32</td>
          <td>14.87</td>
          <td>13.34</td>
          <td>23.27</td>
          <td>13.37</td>
          <td>12.53</td>
          <td>14.24</td>
          <td>19.1</td>
          <td>12.5</td>
          <td>15.89</td>
          <td>12.21</td>
          <td>10.24</td>
          <td>25.06</td>
          <td>11.18</td>
          <td>15.83</td>
          <td>9.34</td>
          <td>11.12</td>
          <td>17.12</td>
          <td>9.61</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  8 modelo =baseline semanas</th>
          <td>43.36</td>
          <td>22.62</td>
          <td>19.29</td>
          <td>17.59</td>
          <td>70.86</td>
          <td>20.6</td>
          <td>41.16</td>
          <td>47.08</td>
          <td>32.09</td>
          <td>18.47</td>
          <td>26.75</td>
          <td>17.16</td>
          <td>25.6</td>
          <td>49.05</td>
          <td>21.84</td>
          <td>34.34</td>
          <td>37.34</td>
          <td>21.71</td>
          <td>26.7</td>
          <td>35.08</td>
        </tr>
        <tr>
          <th>3 MAE Datos con drift en datos y tratando el drift con horizonte=  8 modelo =snarimax semanas</th>
          <td>37.38</td>
          <td>15.08</td>
          <td>18.03</td>
          <td>15.55</td>
          <td>25.73</td>
          <td>15.18</td>
          <td>15.19</td>
          <td>18.07</td>
          <td>22.32</td>
          <td>15.87</td>
          <td>19.68</td>
          <td>14.08</td>
          <td>12.42</td>
          <td>31.84</td>
          <td>13.49</td>
          <td>17.6</td>
          <td>11.03</td>
          <td>12.35</td>
          <td>20.86</td>
          <td>11.72</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  12 modelo =baseline semanas</th>
          <td>57.54</td>
          <td>28.62</td>
          <td>25.62</td>
          <td>23.33</td>
          <td>89.89</td>
          <td>25.9</td>
          <td>55.09</td>
          <td>61.53</td>
          <td>42.98</td>
          <td>23.57</td>
          <td>31.6</td>
          <td>21.09</td>
          <td>32.15</td>
          <td>62.46</td>
          <td>28.71</td>
          <td>41.72</td>
          <td>45.44</td>
          <td>29.14</td>
          <td>36.01</td>
          <td>43.99</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  12 modelo =snarimax semanas</th>
          <td>49.8</td>
          <td>19.38</td>
          <td>22.99</td>
          <td>20.11</td>
          <td>30.82</td>
          <td>19.14</td>
          <td>19.12</td>
          <td>23.96</td>
          <td>26.66</td>
          <td>19.99</td>
          <td>24.21</td>
          <td>16.61</td>
          <td>14.8</td>
          <td>42.76</td>
          <td>17.84</td>
          <td>19.67</td>
          <td>13.28</td>
          <td>14.73</td>
          <td>27.54</td>
          <td>14.01</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  4 modelo =baseline semanas</th>
          <td>35.21</td>
          <td>18.92</td>
          <td>16.98</td>
          <td>15.77</td>
          <td>54.67</td>
          <td>16.46</td>
          <td>30.08</td>
          <td>34.77</td>
          <td>25.55</td>
          <td>15.51</td>
          <td>22.74</td>
          <td>15.13</td>
          <td>20.8</td>
          <td>39.81</td>
          <td>17.75</td>
          <td>28.37</td>
          <td>29.15</td>
          <td>16.97</td>
          <td>22.88</td>
          <td>27.02</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  4 modelo =snarimax semanas</th>
          <td>32.62</td>
          <td>13.54</td>
          <td>16.57</td>
          <td>14.41</td>
          <td>24.73</td>
          <td>14.17</td>
          <td>13.96</td>
          <td>16.33</td>
          <td>20.78</td>
          <td>13.94</td>
          <td>17.71</td>
          <td>13.19</td>
          <td>11.08</td>
          <td>27.8</td>
          <td>12.16</td>
          <td>16.81</td>
          <td>10.03</td>
          <td>11.64</td>
          <td>19.34</td>
          <td>10.63</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  8 modelo =baseline semanas</th>
          <td>46.94</td>
          <td>23.78</td>
          <td>21.08</td>
          <td>19.14</td>
          <td>73.45</td>
          <td>22.25</td>
          <td>43.92</td>
          <td>49.05</td>
          <td>34.94</td>
          <td>20.07</td>
          <td>28.45</td>
          <td>18.27</td>
          <td>26.98</td>
          <td>52.13</td>
          <td>22.94</td>
          <td>35.68</td>
          <td>38.98</td>
          <td>23.2</td>
          <td>29.68</td>
          <td>36.47</td>
        </tr>
        <tr>
          <th>4 MAE Datos con drift en datos y sin tratar el drift con horizonte=  8 modelo =snarimax semanas</th>
          <td>40.74</td>
          <td>16.24</td>
          <td>19.97</td>
          <td>16.9</td>
          <td>27.44</td>
          <td>16.27</td>
          <td>16.48</td>
          <td>19.81</td>
          <td>23.85</td>
          <td>17.38</td>
          <td>21.33</td>
          <td>15.01</td>
          <td>13.22</td>
          <td>34.95</td>
          <td>14.67</td>
          <td>18.54</td>
          <td>11.75</td>
          <td>13.01</td>
          <td>22.95</td>
          <td>12.53</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  12 modelo =baseine semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  12 modelo =snarimax semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  4 modelo =baseline semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  4 modelo =snarimax semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  8 modelo =baseline semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>5 Num Drifts Datos con drift en datos y tratando el drift con horizonte=  8 modelo =snarimax semanas</th>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
          <td>3</td>
        </tr>
        <tr>
          <th>MEAN</th>
          <td>73.63</td>
          <td>24.37</td>
          <td>26.79</td>
          <td>21.89</td>
          <td>41.82</td>
          <td>22.21</td>
          <td>24.0</td>
          <td>30.64</td>
          <td>33.92</td>
          <td>22.28</td>
          <td>28.54</td>
          <td>17.88</td>
          <td>16.75</td>
          <td>62.45</td>
          <td>20.72</td>
          <td>21.08</td>
          <td>14.92</td>
          <td>16.77</td>
          <td>30.04</td>
          <td>14.87</td>
        </tr>
        <tr>
          <th>Num Outliers</th>
          <td>7</td>
          <td>8</td>
          <td>8</td>
          <td>11</td>
          <td>6</td>
          <td>11</td>
          <td>4</td>
          <td>5</td>
          <td>6</td>
          <td>10</td>
          <td>4</td>
          <td>4</td>
          <td>9</td>
          <td>4</td>
          <td>7</td>
          <td>7</td>
          <td>9</td>
          <td>11</td>
          <td>7</td>
          <td>6</td>
        </tr>
        <tr>
          <th>STD</th>
          <td>72.09</td>
          <td>28.23</td>
          <td>32.2</td>
          <td>35.89</td>
          <td>45.65</td>
          <td>28.55</td>
          <td>26.87</td>
          <td>33.84</td>
          <td>39.37</td>
          <td>30.33</td>
          <td>32.4</td>
          <td>21.36</td>
          <td>20.87</td>
          <td>60.49</td>
          <td>25.43</td>
          <td>25.12</td>
          <td>21.41</td>
          <td>21.05</td>
          <td>37.84</td>
          <td>20.55</td>
        </tr>
      </tbody>
    </table>
    </div>



2.2.9 Conclusiones
~~~~~~~~~~~~~~~~~~

-  Para cada ciudad: >En este caso tenemos dos modelos con varios
   horizontes.El modelo **SNARIMAX** que ha sido configurado con sus
   parámetros a partir de los plots de Autocorrlación (ACF) y
   Autocorrelación Parcial (PACF)y otro modelo tomado como Baseline que
   es el **Holtwinter**, en el que también se han ajustado sus
   parámetros para un buen rendimiento. Lo primero que hay que destacar
   que a mayor horizonte los modelos predicen peor, tienen más error.
   Obviamente como en el caso del Nowcasting si se tratan los outliers
   se obtienen mejores prestaciones que si no se hace. Lo mismo ocurre
   con el drift. Se ha introducido un drift artificial para hacer estas
   comprobaciones con el detector de drifts ADWIN. Cada vez que se
   detecta un drift, tanto el modelo como el detector son reiniciados.

-  Comparando ciudades: > Comparando las mediciones entre ciudades, las
   ciudades que menor MAE presentan independientemente del modelo usado,
   aunque por supuesto hay diferencias entre modelos y siguen siendo los
   menores MAE aquellos que tratan los outliers y el drift. Como en la
   comparación en cada ciudad el modelo para cada ciudad el mejor modelo
   es el **SNARIMAX** Al igual que con el Nowcating, las mejores
   ciudades, son aquellas que presentan una menor dispersión, menor
   desviación tipica y menor media, en los datos. Estas ciudades son
   aquellas que presentan una menor población o han contraido un menor
   número de casos de varicela. A mayor dispersión en los datos, mayor
   es el error.

2.3 Estimacion de la Incertidumbre, mediante regresión por cuantiles.
---------------------------------------------------------------------

En este apartado vamos a estudiar una estimación de la incertidumbre, ya
que muchas veces una predicción exacta puede no ser real por lo que se
producirá un intervalo de prediccción para cada predicción. Estos
modelos son más robustos frente a outliers y son una forma de predecir
relaciones entre variables que no tienen relación entre si o
simplemtente tienen una relación débil.\ `Quantile
Regression <https://medium.com/the-artificial-impostor/quantile-regression-part-1-e25bdd8d9d43>`__.
Para ello vamos a tomar el mejor modelo de regresión de todos los que
hemos análizado, el Modelo de Regresión Lineal y vamos a obtener estas
“regiones de confianza”. Además vamos a testear el comportamiento tanto
con outliers como tratando los outliers. Lo mismo vamos a hacer con el
drift.

.. code:: ipython3

    def make_model(alpha):
        """Returns the model itself, using pipelines from riverML
        @alpha: quantile to be observed
        """
    
        extract_features = compose.TransformerUnion(get_ordinal_date, get_month_distances)
    
        scale = preprocessing.StandardScaler()
    
        learn = linear_model.LinearRegression(
            intercept_lr=0.,
            optimizer=optim.SGD(0.07),
            loss=optim.losses.Quantile(alpha=alpha)
        )
        
        model = extract_features | scale | learn
        model = preprocessing.TargetStandardScaler(regressor=model)
    
        return model
    # Dataframe to store the values of the range for prediction interval
    df_uncertainity=pd.DataFrame(columns=data_orig.columns)
    
    def evaluate_uncertainity(df_data,ax, column,check_outliers):
      """
      Function for training the trhee models relative to the 3 quantiles
      lower, center and upper
      @df_data: data
      @ax: axis to plot the predictions
      @column: value to store the values in the dataframe df_uncertainity
      @check_outliers: [True|False] if outliers has to be checked or not
      """
      metric = metrics.MAE()
    
      models = {
          'lower': make_model(alpha=0.05),
          'center': make_model(alpha=0.5),
          'upper': make_model(alpha=0.95)
      }
    
      dates = []
      y_trues = []
      y_preds = {
          'lower': [],
          'center': [],
          'upper': []
      }
      media=df_data.mean()
      stdev=df_data.std()
      outlier_value= media + (3*stdev)
      for x, y in df_data.T.items():
        if  check_outliers:
            if y <= outlier_value:
              y_trues.append(y)
              dates.append(x)
    
              for name, model in models.items():
                  y_preds[name].append(model.predict_one(x))
                  model.learn_one(x, y)
    
              # Update the error metric
              metric.update(y, y_preds['center'][-1])
        else:
              y_trues.append(y)
              dates.append(x)
    
              for name, model in models.items():
                  y_preds[name].append(model.predict_one(x))
                  model.learn_one(x, y)
    
              # Update the error metric
              metric.update(y, y_preds['center'][-1])
    
      # Plot the results
      if check_outliers:
        df_uncertainity.at['1 Max Upper limit handling outliers', column] = round(max(y_preds['upper']),2)
        df_uncertainity.at['1 Mean Upper limit handling outliers', column] = round(sum(y_preds['upper'])/len(y_preds['upper']),2)
        df_uncertainity.at['1 Mean Center limit handling outliers', column] = round(sum(y_preds['center'])/len(y_preds['center']),2)
        df_uncertainity.at['1 Mean Lower limit handling outliers', column] = round(sum(y_preds['lower'])/len(y_preds['lower']),2)
        df_uncertainity.at['1 Min Lower limit handling outliers', column] = round(min(y_preds['lower']),2)
        df_uncertainity.at['1 MAE Handling outliers', column] = round(metric.get(),2)
       
      else:
        df_uncertainity.at['2 Max Upper limit without handling outliers', column] = round(max(y_preds['upper']),2)
        df_uncertainity.at['2 Mean Upper limit without handling outliers', column] = round(sum(y_preds['upper'])/len(y_preds['upper']),2)
        df_uncertainity.at['2 Mean Center limit without handling outliers', column] = round(sum(y_preds['center'])/len(y_preds['center']),2)
        df_uncertainity.at['2 Mean Lower limit without handling outliers', column] = round(sum(y_preds['lower'])/len(y_preds['lower']),2)
        df_uncertainity.at['2 Min Lower limit without handling outliers', column] = round(min(y_preds['lower']),2)
        df_uncertainity.at['2 MAE Without Handling outliers', column] = round(metric.get(),2)
    
      ax.grid(alpha=0.75)
      ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Truth')
      ax.plot(dates, y_preds['center'], lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
      ax.fill_between(dates, y_preds['lower'], y_preds['upper'], color='blue', alpha=0.3, label='Prediction interval')
      ax.legend()
      ax.set_title(metric)
    
    

.. code:: ipython3

    def evaluate_uncertainity_drift(df_data,ax, column,check_drift):
      """
      Function for training the trhee models relative to the 3 quantiles
      lower, center and upper
      @df_data: data
      @ax: axis to plot the predictions
      @column: value to store the values in the dataframe df_uncertainity
      @check_drift: [True|False] if drift has to be checked or not
      """
     
      drifts=[]
      metric = metrics.MAE()
    
      models = {
          'lower': make_model(alpha=0.05),
          'center': make_model(alpha=0.5),
          'upper': make_model(alpha=0.95)
      }
    
      dates = []
      y_trues = []
      y_preds = {
          'lower': [],
          'center': [],
          'upper': []
      }
      media=df_data.mean()
      stdev=df_data.std()
      outlier_value= media + (3*stdev)
    
      #contador de Drifts
      num_drifts = 0 
      drifts=[]
    
      if check_drift:
        #Inicializamos el detector de Drift
        drift_detector = drift.ADWIN()
        for x, y in df_data.T.items():
          drift_detector.update(y)
    
          #if y <= outlier_value:
          y_trues.append(y)
          dates.append(x)
          if drift_detector.drift_detected:
            drifts.append(x)
          for name, model in models.items():
              if not drift_detector.drift_detected:
                y_preds[name].append(model.predict_one(x))
                model.learn_one(x, y)
                
              else: #if drift detected
                #print("drift_detected")
                if name=='lower':
                  #print("restarting lower")
                  model = make_model(alpha=0.05)
                elif name=='center':
                  #print("restarting center")
                  model=make_model(alpha=0.5)
                elif name=="upper":
                  #print("restarting uper")
                  model=make_model(alpha=0.95)
                y_preds[name].append(model.predict_one(x))
                #model.learn_one(x, y)
          # Update the error metric
          metric.update(y, y_preds['center'][-1])
    
        drift_detector=drift.ADWIN() #reiniciamos el drift detector
      else:
          
          for x, y in df_data.T.items():
            
            #if y <= outlier_value:
                y_trues.append(y)
                dates.append(x)
                for name, model in models.items():
                    y_preds[name].append(model.predict_one(x))
                    model.learn_one(x, y)
    
                # Update the error metric
                metric.update(y, y_preds['center'][-1])
          
    
    
      # Plot the results
      if check_drift:
        df_uncertainity.at['3 Max Upper limit handling drift', column] = round(max(y_preds['upper']),2)
        df_uncertainity.at['3 Mean Upper limit handling drift', column] = round(sum(y_preds['upper'])/len(y_preds['upper']),2)
        df_uncertainity.at['3 Mean Center limit handling drift', column] = round(sum(y_preds['center'])/len(y_preds['center']),2)
        df_uncertainity.at['3 Mean Lower limit handling drift', column] = round(sum(y_preds['lower'])/len(y_preds['lower']),2)
        df_uncertainity.at['3 MAE  Handling drift', column] = round(metric.get(),2)
        df_uncertainity.at['3 Min Lower limit handling drift', column] = round(min(y_preds['lower']),2)
      else:
        df_uncertainity.at['4 Max Upper limit without handling drift', column] = round(max(y_preds['upper']),2)
        df_uncertainity.at['4 Mean Upper limit without handling drift', column] = round(sum(y_preds['upper'])/len(y_preds['upper']),2)
        df_uncertainity.at['4 Mean Center limit without handling drift', column] = round(sum(y_preds['center'])/len(y_preds['center']),2)
        df_uncertainity.at['4 Mean Lower limit without handling drift', column] = round(sum(y_preds['lower'])/len(y_preds['lower']),2)
        df_uncertainity.at['4 MAE Without handling drift', column] = round(metric.get(),2)
        df_uncertainity.at['4 Min Lower limit without handling drift', column] = round(min(y_preds['lower']),2)
    
      if drifts is not None:
          for drift_detected in drifts:
                  ax.axvline(drift_detected, color='red')
      ax.grid(alpha=0.75)
      ax.plot(dates, y_trues, lw=3, color='#2ecc71', alpha=0.8, label='Truth')
      ax.plot(dates, y_preds['center'], lw=3, color='#e74c3c', alpha=0.8, label='Prediction')
      ax.fill_between(dates, y_preds['lower'], y_preds['upper'], color='blue', alpha=0.3, label='Prediction interval')
      ax.set_xlabel(column)
      ax.legend()
      ax.set_title(metric)

2.3.1 Testing the model without handling outliers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_uncertainity(df_data,ax,label,check_outliers=False)
            i += 1
    fig.suptitle("Comportamiento del modelo, sin tratar los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_205_0.png


2.3.2 Testing the model handling outliers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= data_orig.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_uncertainity(df_data,ax,label,check_outliers=True)
            i += 1
    fig.suptitle("Comportamiento del modelo, tratando los Outliers", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_207_0.png


2.3.1 Testing the model without handling concept drift
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_uncertainity_drift(df_data,ax,label,check_drift=False)
            i += 1
            
        
    fig.suptitle("Comportamiento del modelo, sin el drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_209_0.png


2.3.3 Testing the model handling concept drift
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    fig, axes = plt.subplots(nrows=4, ncols=5, figsize=(25, 14))
    i = 0
    for row in axes:
        for ax in row:
            df_data= df_data_orig_drifted.iloc[:, i]
            label=data_orig.columns[i]
            evaluate_uncertainity_drift(df_data,ax,label,check_drift=True)
            i += 1
            
        
    fig.suptitle("Comportamiento del modelo, Tratando el drift", fontsize=20)
    plt.tight_layout()
    plt.show()



.. image:: output_211_0.png


.. code:: ipython3

    df_uncertainity.sort_index(ascending=True)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BUDAPEST</th>
          <th>BARANYA</th>
          <th>BACS</th>
          <th>BEKES</th>
          <th>BORSOD</th>
          <th>CSONGRAD</th>
          <th>FEJER</th>
          <th>GYOR</th>
          <th>HAJDU</th>
          <th>HEVES</th>
          <th>JASZ</th>
          <th>KOMAROM</th>
          <th>NOGRAD</th>
          <th>PEST</th>
          <th>SOMOGY</th>
          <th>SZABOLCS</th>
          <th>TOLNA</th>
          <th>VAS</th>
          <th>VESZPREM</th>
          <th>ZALA</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1 MAE Handling outliers</th>
          <td>41.46</td>
          <td>18.52</td>
          <td>20.42</td>
          <td>19.46</td>
          <td>32.14</td>
          <td>20.03</td>
          <td>19.56</td>
          <td>20.24</td>
          <td>26.15</td>
          <td>17.94</td>
          <td>21.92</td>
          <td>13.82</td>
          <td>13.27</td>
          <td>36.0</td>
          <td>15.86</td>
          <td>19.4</td>
          <td>14.73</td>
          <td>15.16</td>
          <td>21.97</td>
          <td>12.74</td>
        </tr>
        <tr>
          <th>1 Max Upper limit handling outliers</th>
          <td>350.35</td>
          <td>160.75</td>
          <td>272.57</td>
          <td>200.94</td>
          <td>351.88</td>
          <td>169.4</td>
          <td>199.61</td>
          <td>302.51</td>
          <td>329.84</td>
          <td>196.71</td>
          <td>275.36</td>
          <td>205.87</td>
          <td>116.36</td>
          <td>322.3</td>
          <td>171.68</td>
          <td>178.48</td>
          <td>129.03</td>
          <td>140.93</td>
          <td>238.46</td>
          <td>140.19</td>
        </tr>
        <tr>
          <th>1 Mean Center limit handling outliers</th>
          <td>92.53</td>
          <td>32.68</td>
          <td>34.61</td>
          <td>26.07</td>
          <td>53.65</td>
          <td>28.2</td>
          <td>30.87</td>
          <td>39.94</td>
          <td>44.95</td>
          <td>25.38</td>
          <td>38.61</td>
          <td>23.7</td>
          <td>20.48</td>
          <td>84.26</td>
          <td>24.77</td>
          <td>27.86</td>
          <td>18.45</td>
          <td>19.86</td>
          <td>37.42</td>
          <td>17.23</td>
        </tr>
        <tr>
          <th>1 Mean Lower limit handling outliers</th>
          <td>26.16</td>
          <td>2.95</td>
          <td>1.6</td>
          <td>-7.15</td>
          <td>4.62</td>
          <td>-3.04</td>
          <td>1.3</td>
          <td>9.6</td>
          <td>4.2</td>
          <td>-1.11</td>
          <td>2.15</td>
          <td>3.41</td>
          <td>0.89</td>
          <td>24.79</td>
          <td>2.66</td>
          <td>-1.77</td>
          <td>-1.55</td>
          <td>-2.46</td>
          <td>1.28</td>
          <td>-1.89</td>
        </tr>
        <tr>
          <th>1 Mean Upper limit handling outliers</th>
          <td>183.62</td>
          <td>70.91</td>
          <td>77.72</td>
          <td>67.16</td>
          <td>115.31</td>
          <td>70.85</td>
          <td>75.85</td>
          <td>83.5</td>
          <td>95.15</td>
          <td>69.78</td>
          <td>86.29</td>
          <td>59.56</td>
          <td>50.81</td>
          <td>158.71</td>
          <td>61.01</td>
          <td>71.03</td>
          <td>51.17</td>
          <td>57.16</td>
          <td>88.53</td>
          <td>51.08</td>
        </tr>
        <tr>
          <th>1 Min Lower limit handling outliers</th>
          <td>-222.06</td>
          <td>-176.28</td>
          <td>-200.16</td>
          <td>-163.51</td>
          <td>-218.12</td>
          <td>-97.45</td>
          <td>-184.61</td>
          <td>-212.75</td>
          <td>-251.01</td>
          <td>-125.2</td>
          <td>-125.54</td>
          <td>-67.42</td>
          <td>-69.57</td>
          <td>-233.61</td>
          <td>-102.44</td>
          <td>-110.57</td>
          <td>-53.37</td>
          <td>-80.91</td>
          <td>-206.31</td>
          <td>-100.88</td>
        </tr>
        <tr>
          <th>2 MAE Without Handling outliers</th>
          <td>45.35</td>
          <td>19.72</td>
          <td>22.72</td>
          <td>25.91</td>
          <td>35.63</td>
          <td>22.79</td>
          <td>20.79</td>
          <td>21.39</td>
          <td>29.43</td>
          <td>20.93</td>
          <td>23.9</td>
          <td>15.66</td>
          <td>14.6</td>
          <td>37.9</td>
          <td>18.06</td>
          <td>23.43</td>
          <td>15.88</td>
          <td>17.32</td>
          <td>24.38</td>
          <td>13.99</td>
        </tr>
        <tr>
          <th>2 Max Upper limit without handling outliers</th>
          <td>426.0</td>
          <td>162.56</td>
          <td>272.57</td>
          <td>516.79</td>
          <td>356.2</td>
          <td>212.52</td>
          <td>228.33</td>
          <td>319.71</td>
          <td>401.23</td>
          <td>235.54</td>
          <td>295.81</td>
          <td>223.38</td>
          <td>151.11</td>
          <td>359.96</td>
          <td>215.4</td>
          <td>395.65</td>
          <td>147.52</td>
          <td>209.16</td>
          <td>319.49</td>
          <td>140.19</td>
        </tr>
        <tr>
          <th>2 Mean Center limit without handling outliers</th>
          <td>91.98</td>
          <td>35.32</td>
          <td>35.43</td>
          <td>27.99</td>
          <td>55.5</td>
          <td>29.73</td>
          <td>33.66</td>
          <td>40.8</td>
          <td>46.13</td>
          <td>28.82</td>
          <td>40.12</td>
          <td>24.83</td>
          <td>21.04</td>
          <td>83.83</td>
          <td>27.23</td>
          <td>27.31</td>
          <td>19.26</td>
          <td>21.93</td>
          <td>41.43</td>
          <td>18.14</td>
        </tr>
        <tr>
          <th>2 Mean Lower limit without handling outliers</th>
          <td>26.53</td>
          <td>1.74</td>
          <td>-0.6</td>
          <td>-12.87</td>
          <td>6.13</td>
          <td>-5.51</td>
          <td>0.95</td>
          <td>6.24</td>
          <td>1.91</td>
          <td>-2.97</td>
          <td>2.39</td>
          <td>0.62</td>
          <td>-1.29</td>
          <td>24.02</td>
          <td>0.7</td>
          <td>-5.84</td>
          <td>-1.42</td>
          <td>-4.52</td>
          <td>-0.2</td>
          <td>-2.29</td>
        </tr>
        <tr>
          <th>2 Mean Upper limit without handling outliers</th>
          <td>200.08</td>
          <td>77.65</td>
          <td>84.02</td>
          <td>86.44</td>
          <td>128.96</td>
          <td>83.5</td>
          <td>78.79</td>
          <td>89.2</td>
          <td>106.91</td>
          <td>84.32</td>
          <td>90.38</td>
          <td>58.19</td>
          <td>59.6</td>
          <td>172.35</td>
          <td>69.67</td>
          <td>82.76</td>
          <td>56.3</td>
          <td>64.92</td>
          <td>98.49</td>
          <td>51.62</td>
        </tr>
        <tr>
          <th>2 Min Lower limit without handling outliers</th>
          <td>-222.06</td>
          <td>-176.28</td>
          <td>-215.66</td>
          <td>-342.44</td>
          <td>-266.09</td>
          <td>-97.45</td>
          <td>-178.47</td>
          <td>-242.27</td>
          <td>-308.43</td>
          <td>-125.2</td>
          <td>-188.13</td>
          <td>-109.06</td>
          <td>-69.57</td>
          <td>-233.61</td>
          <td>-135.63</td>
          <td>-186.78</td>
          <td>-53.37</td>
          <td>-97.79</td>
          <td>-206.31</td>
          <td>-100.88</td>
        </tr>
        <tr>
          <th>3 MAE  Handling drift</th>
          <td>37.97</td>
          <td>16.51</td>
          <td>18.9</td>
          <td>23.07</td>
          <td>30.98</td>
          <td>17.69</td>
          <td>16.92</td>
          <td>19.73</td>
          <td>25.34</td>
          <td>19.2</td>
          <td>19.59</td>
          <td>13.0</td>
          <td>12.63</td>
          <td>31.01</td>
          <td>15.52</td>
          <td>18.19</td>
          <td>13.11</td>
          <td>13.53</td>
          <td>21.37</td>
          <td>11.4</td>
        </tr>
        <tr>
          <th>3 Max Upper limit handling drift</th>
          <td>426.0</td>
          <td>161.18</td>
          <td>272.57</td>
          <td>516.79</td>
          <td>356.2</td>
          <td>205.94</td>
          <td>228.33</td>
          <td>319.71</td>
          <td>401.23</td>
          <td>237.29</td>
          <td>295.81</td>
          <td>223.38</td>
          <td>149.19</td>
          <td>321.49</td>
          <td>215.4</td>
          <td>395.65</td>
          <td>147.52</td>
          <td>209.16</td>
          <td>319.49</td>
          <td>140.19</td>
        </tr>
        <tr>
          <th>3 Mean Center limit handling drift</th>
          <td>67.85</td>
          <td>23.86</td>
          <td>24.4</td>
          <td>21.7</td>
          <td>38.91</td>
          <td>20.69</td>
          <td>22.63</td>
          <td>29.61</td>
          <td>33.29</td>
          <td>21.13</td>
          <td>28.13</td>
          <td>17.94</td>
          <td>15.95</td>
          <td>60.47</td>
          <td>19.6</td>
          <td>19.21</td>
          <td>14.82</td>
          <td>16.38</td>
          <td>29.06</td>
          <td>13.75</td>
        </tr>
        <tr>
          <th>3 Mean Lower limit handling drift</th>
          <td>9.24</td>
          <td>-2.0</td>
          <td>-3.01</td>
          <td>-15.81</td>
          <td>-3.06</td>
          <td>-6.93</td>
          <td>-1.62</td>
          <td>-1.93</td>
          <td>-3.93</td>
          <td>-7.26</td>
          <td>-0.61</td>
          <td>-2.69</td>
          <td>-3.47</td>
          <td>7.74</td>
          <td>-2.98</td>
          <td>-6.11</td>
          <td>-3.46</td>
          <td>-4.08</td>
          <td>-7.51</td>
          <td>-2.55</td>
        </tr>
        <tr>
          <th>3 Mean Upper limit handling drift</th>
          <td>170.91</td>
          <td>62.93</td>
          <td>62.82</td>
          <td>75.06</td>
          <td>104.79</td>
          <td>63.22</td>
          <td>58.94</td>
          <td>71.31</td>
          <td>83.31</td>
          <td>76.9</td>
          <td>64.11</td>
          <td>48.03</td>
          <td>53.86</td>
          <td>139.0</td>
          <td>57.1</td>
          <td>59.16</td>
          <td>48.64</td>
          <td>45.99</td>
          <td>81.88</td>
          <td>40.22</td>
        </tr>
        <tr>
          <th>3 Min Lower limit handling drift</th>
          <td>-222.06</td>
          <td>-176.28</td>
          <td>-215.66</td>
          <td>-342.44</td>
          <td>-266.09</td>
          <td>-97.45</td>
          <td>-178.47</td>
          <td>-242.27</td>
          <td>-308.43</td>
          <td>-125.2</td>
          <td>-188.13</td>
          <td>-109.06</td>
          <td>-69.57</td>
          <td>-233.61</td>
          <td>-135.63</td>
          <td>-186.78</td>
          <td>-53.37</td>
          <td>-97.79</td>
          <td>-206.31</td>
          <td>-100.88</td>
        </tr>
        <tr>
          <th>4 MAE Without handling drift</th>
          <td>38.76</td>
          <td>16.62</td>
          <td>18.88</td>
          <td>23.21</td>
          <td>30.62</td>
          <td>17.72</td>
          <td>16.62</td>
          <td>19.78</td>
          <td>25.19</td>
          <td>19.36</td>
          <td>19.56</td>
          <td>13.09</td>
          <td>12.76</td>
          <td>31.63</td>
          <td>15.94</td>
          <td>18.25</td>
          <td>13.31</td>
          <td>13.81</td>
          <td>21.57</td>
          <td>11.35</td>
        </tr>
        <tr>
          <th>4 Max Upper limit without handling drift</th>
          <td>426.0</td>
          <td>160.75</td>
          <td>272.57</td>
          <td>516.79</td>
          <td>356.2</td>
          <td>205.94</td>
          <td>228.33</td>
          <td>319.71</td>
          <td>401.23</td>
          <td>235.54</td>
          <td>295.81</td>
          <td>223.38</td>
          <td>149.58</td>
          <td>321.49</td>
          <td>215.4</td>
          <td>395.65</td>
          <td>147.52</td>
          <td>209.16</td>
          <td>319.49</td>
          <td>140.19</td>
        </tr>
        <tr>
          <th>4 Mean Center limit without handling drift</th>
          <td>67.62</td>
          <td>24.77</td>
          <td>24.73</td>
          <td>21.45</td>
          <td>39.62</td>
          <td>20.68</td>
          <td>23.09</td>
          <td>30.06</td>
          <td>33.25</td>
          <td>22.02</td>
          <td>27.38</td>
          <td>18.17</td>
          <td>16.36</td>
          <td>60.16</td>
          <td>19.88</td>
          <td>19.25</td>
          <td>15.29</td>
          <td>16.42</td>
          <td>30.16</td>
          <td>13.64</td>
        </tr>
        <tr>
          <th>4 Mean Lower limit without handling drift</th>
          <td>9.19</td>
          <td>-1.69</td>
          <td>-3.11</td>
          <td>-16.71</td>
          <td>-0.4</td>
          <td>-6.57</td>
          <td>-1.17</td>
          <td>-1.89</td>
          <td>-3.91</td>
          <td>-6.56</td>
          <td>-0.18</td>
          <td>-2.38</td>
          <td>-3.11</td>
          <td>7.63</td>
          <td>-2.71</td>
          <td>-6.05</td>
          <td>-3.35</td>
          <td>-4.31</td>
          <td>-7.04</td>
          <td>-2.52</td>
        </tr>
        <tr>
          <th>4 Mean Upper limit without handling drift</th>
          <td>174.03</td>
          <td>63.29</td>
          <td>62.78</td>
          <td>76.6</td>
          <td>103.99</td>
          <td>63.19</td>
          <td>59.34</td>
          <td>70.51</td>
          <td>83.12</td>
          <td>76.89</td>
          <td>64.76</td>
          <td>46.68</td>
          <td>54.08</td>
          <td>138.83</td>
          <td>57.99</td>
          <td>59.03</td>
          <td>48.67</td>
          <td>46.49</td>
          <td>82.28</td>
          <td>40.2</td>
        </tr>
        <tr>
          <th>4 Min Lower limit without handling drift</th>
          <td>-222.06</td>
          <td>-176.28</td>
          <td>-215.66</td>
          <td>-342.44</td>
          <td>-266.09</td>
          <td>-97.45</td>
          <td>-178.47</td>
          <td>-242.27</td>
          <td>-308.43</td>
          <td>-125.2</td>
          <td>-188.13</td>
          <td>-109.06</td>
          <td>-69.57</td>
          <td>-233.61</td>
          <td>-135.63</td>
          <td>-186.78</td>
          <td>-53.37</td>
          <td>-97.79</td>
          <td>-206.31</td>
          <td>-100.88</td>
        </tr>
      </tbody>
    </table>
    </div>



2.3.4 Resultados Estimación de Incertidumbre
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Para este apartado se ha escogido el modelo que mejor métricas a
obtenido durante todos los apartados anteriores. Se ha escogido el
Linear Regression aunque se ha modificado un poquito introduciendo el
parametro *intercept_lr=0*, para que no coja ningun valor por defecto.
Este valor está por defecto a 0.01. \* Outliers: Se ha visto claramente
en la tabla de resultados que para el tratamiento de outliers, la zona
de confianza parametrizada con los siguientes parámetros models = {
‘lower’: make_model(alpha=0.05), ‘center’: make_model(alpha=0.5),
‘upper’: make_model(alpha=0.95) } se ha reducido el el rango entre el
límite superior y el límite inferior, además de que el modelo produce
mejor métrica MAE. Con lo cual el tratamiento de outliers ,sí mejora
tanto la precisión del Modelo como la zona de confianza para
predicciones individuales.

-  Concept Drift: Pare el Concept Drift no es tan clara la mejoría,
   aunque esta sí existe aunque menos notoria que con el tratamiento de
   outliers por que a primera vista los rangos de la zona de confianza,
   Max limite superior y Min límite inferior, son iguales, sí se puede
   apreciar que el modelo obtiene una métrica MAE mejorada y las medias
   de tanto los limites inferior y superior también mejoran, aunque no
   tanto como en el tratamiento de outliers.

Estos resultados, son así por que el Intervalo de Prediccion (zona de
confianza)predice la distribución de valores futuros
**individualmente**. Mientras que el Intervalo de Confianza,relativo a
las métricas en este caso, MAE estima la media de la población
apoyandose en valores anteriores. Por eso la métrica mejora al manejar
el concept drift, hace que el modelo produzca mejor métrica, no así
tanto en la zona de confianza. Sin embargo al tratar los outliers ya se
están eliminando los valores extremos, reduciendo así la zona de
confianza y los valores de la métrica MAE.

2.4 Explicacion del modelo
--------------------------

.. code:: ipython3

    #Instalamos la libreria SHAP y reinstalamos la libreria Numpy, con la correcta versión,
    # si no todo el notebook va a fallar
    
    !pip install shap
    #!pip install --force-reinstall numpy==1.23.4
    


.. parsed-literal::

    Requirement already satisfied: shap in c:\users\jrmr\anaconda3\lib\site-packages (0.41.0)
    Requirement already satisfied: slicer==0.0.7 in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (0.0.7)
    Requirement already satisfied: cloudpickle in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (2.0.0)
    Requirement already satisfied: pandas in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (1.4.4)
    Requirement already satisfied: packaging>20.9 in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (21.3)
    Requirement already satisfied: numba in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (0.55.1)
    Requirement already satisfied: tqdm>4.25.0 in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (4.64.1)
    Requirement already satisfied: scikit-learn in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (1.0.2)
    Requirement already satisfied: scipy in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (1.9.1)
    Requirement already satisfied: numpy in c:\users\jrmr\anaconda3\lib\site-packages (from shap) (1.21.0)
    Requirement already satisfied: pyparsing!=3.0.5,>=2.0.2 in c:\users\jrmr\anaconda3\lib\site-packages (from packaging>20.9->shap) (3.0.9)
    Requirement already satisfied: colorama in c:\users\jrmr\anaconda3\lib\site-packages (from tqdm>4.25.0->shap) (0.4.5)
    Requirement already satisfied: setuptools in c:\users\jrmr\anaconda3\lib\site-packages (from numba->shap) (63.4.1)
    Requirement already satisfied: llvmlite<0.39,>=0.38.0rc1 in c:\users\jrmr\anaconda3\lib\site-packages (from numba->shap) (0.38.0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\jrmr\anaconda3\lib\site-packages (from pandas->shap) (2022.1)
    Requirement already satisfied: python-dateutil>=2.8.1 in c:\users\jrmr\anaconda3\lib\site-packages (from pandas->shap) (2.8.2)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\users\jrmr\anaconda3\lib\site-packages (from scikit-learn->shap) (2.2.0)
    Requirement already satisfied: joblib>=0.11 in c:\users\jrmr\anaconda3\lib\site-packages (from scikit-learn->shap) (1.1.0)
    Requirement already satisfied: six>=1.5 in c:\users\jrmr\anaconda3\lib\site-packages (from python-dateutil>=2.8.1->pandas->shap) (1.16.0)
    

.. code:: ipython3

    #creamos dos variables artificiales  para qiue tenga sentido la explicación del modelo
    !pip install --force-reinstall numpy==1.21
    import sklearn
    from sklearn.linear_model import LinearRegression
    from matplotlib import pyplot as plt
    import numpy as np
    import shap
    import pandas as pd
    data_orig_explic = pd.read_csv('C:/Users/jrmr/Master/TFM/PEC3/hungary_chickenpox/hungary_chickenpox.csv')
    data_orig_explic['Date'] = pd.to_datetime(data_orig_explic['Date'],format="%d/%m/%Y") # convertimos a fecha
    data_orig_explic["ordinal_date"]=data_orig_explic["Date"].apply(lambda x: x.toordinal())
    data_orig_explic["day"]=data_orig_explic["Date"].apply(lambda x: x.day)
    data_orig_explic["month"]=data_orig_explic["Date"].apply(lambda x: x.month)
    data_orig_explic["year"]=data_orig_explic["Date"].apply(lambda x: x.year)
    data_orig_explic['lag_1'] = data_orig_explic['BUDAPEST'].shift(1) #suponemos que el valor anterior afecta mucho
    
    data_orig_explic['lag_1']=data_orig_explic['lag_1'].fillna(0)
    datos_a_explicar=data_orig_explic[['BUDAPEST','ordinal_date','day','month','year',"lag_1"]]
    datos_a_explicar.head(5)


.. parsed-literal::

    ERROR: pip's dependency resolver does not currently take into account all the packages that are installed. This behaviour is the source of the following dependency conflicts.
    daal4py 2021.6.0 requires daal==2021.4.0, which is not installed.
    river 0.14.0 requires numpy>=1.23.4, but you have numpy 1.21.0 which is incompatible.
    

.. parsed-literal::

    Collecting numpy==1.21
      Using cached numpy-1.21.0-cp39-cp39-win_amd64.whl (14.0 MB)
    Installing collected packages: numpy
      Attempting uninstall: numpy
        Found existing installation: numpy 1.21.0
        Uninstalling numpy-1.21.0:
          Successfully uninstalled numpy-1.21.0
    Successfully installed numpy-1.21.0
    



.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>BUDAPEST</th>
          <th>ordinal_date</th>
          <th>day</th>
          <th>month</th>
          <th>year</th>
          <th>lag_1</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>168</td>
          <td>731949</td>
          <td>3</td>
          <td>1</td>
          <td>2005</td>
          <td>0.0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>157</td>
          <td>731956</td>
          <td>10</td>
          <td>1</td>
          <td>2005</td>
          <td>168.0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>96</td>
          <td>731963</td>
          <td>17</td>
          <td>1</td>
          <td>2005</td>
          <td>157.0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>163</td>
          <td>731970</td>
          <td>24</td>
          <td>1</td>
          <td>2005</td>
          <td>96.0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>122</td>
          <td>731977</td>
          <td>31</td>
          <td>1</td>
          <td>2005</td>
          <td>163.0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    import sklearn
    from sklearn.linear_model import LinearRegression
    from matplotlib import pyplot as plt
    import numpy as np
    import shap
    
    X=data_orig_explic[['ordinal_date','day','month','year',"lag_1"]]
    y=data_orig_explic[['BUDAPEST']]
    model = sklearn.linear_model.LinearRegression( )
    model.fit(X, y)
    explainer = shap.LinearExplainer(model, X, feature_dependence="correlation_dependent")
    shap_values = explainer.shap_values(X)
    shap.summary_plot(shap_values, X, plot_type="bar")
    


.. parsed-literal::

    The option feature_dependence has been renamed to feature_perturbation!
    The feature_perturbation option is now deprecated in favor of using the appropriate masker (maskers.Independent, or maskers.Impute)
    


.. parsed-literal::

    Estimating transforms:   0%|          | 0/1000 [00:00<?, ?it/s]



.. image:: output_218_2.png


.. code:: ipython3

    shap.summary_plot(shap_values, X, feature_names=X.columns)



.. image:: output_219_0.png


2.4.1 Resultado de la explicación del modelo.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Como podemos ver en el primer gráfico, la librería ordena de mayor a
menor la influcencia de las variables en el modelo fina. La que mas
influye es el valor en el momento t-1, luego el mes, el ordinal de la
fecha, el año y el dia. Al ser una serie de datos correlacionada el
resultado es lógico. Luego hemos obtenido un *summary_plot*, que a parte
de contarnos la importancia de las variables, también ordena las
variables por orden de importancia, nos muestra si éstas tienen un
impacto mayor o menor en la predicción. El color azul nos dice si esa
variable fue importante o no para esa fila del dataset. La ubicación
horizontal nos dice eual es el efecto de esa variable en la predicción
mayor o menor.
